# MIT 1.3.1 — DivvyDiary Sync 2.0

## Nauja

- Multi-file CSV import viename lange.
- Automatinis failų atpažinimas:
  - Portfolio
  - Asset Allocation
  - Sector Allocation
  - Country Allocation
  - Region Allocation
  - Dividend History
- External Data sluoksnis pildomas iš DivvyDiary eksportų.
- Portfolio CSV atnaujina holdings.
- Dividend CSV pildo dividend history.
- Allocation CSV pildo validacijai reikalingus duomenis.

## Kaip naudoti

1. Atidaryk `index.html`.
2. Eik į Sync Center.
3. Pasirink kelis DivvyDiary CSV failus vienu metu.
4. Importuok į Marius arba Žmona.
5. Po importo spausk Export JSON.

## Kitas žingsnis

MIT 1.3.2 — Validation Center.


## MIT 1.3.1.1 pataisymas

Pataisyta portfelių priskyrimo klaida:
- `Import Marius Files` visada naudoja `PORT_MARIUS`.
- `Import Žmona Files` visada naudoja `PORT_WIFE`.
- Jei senoje localStorage bazėje buvo seni portfelių ID, jie normalizuojami.
- Sync Center pridėta `Portfolio Assignment` lentelė, kur matosi Marius / Žmona pozicijų skaičius ir vertė.


## MIT 1.3.1.2 pataisymai

- External Data dabar saugoma atskirai:
  - `PORT_MARIUS`
  - `PORT_WIFE`
- Dividend History taip pat saugoma pagal portfelį.
- Šeimos vaizdas susumuoja abu portfelius.
- Portfolio Assignment rodo:
  - Marius pozicijų skaičių ir vertę;
  - Žmonos pozicijų skaičių ir vertę;
  - Šeimos bendrą vertę;
  - dividendų eilučių skaičių.
- Importuojant Marius failus, žmonos duomenys nebeperrašomi ir atvirkščiai.


## MIT 1.3.1.3 pataisymai

- Nebenaudojami portfelių pavadinimai importui.
- Marius importo mygtukas tiesiogiai siunčia duomenis į `PORT_MARIUS`.
- Žmonos importo mygtukas tiesiogiai siunčia duomenis į `PORT_WIFE`.
- Importuojant portfolio CSV, seno to portfelio DivvyDiary holdings išvalomi ir sukuriami iš naujo.
- Tai pašalina situaciją, kai Marius rodo Žmonos skaičius arba Žmona lieka nulis.


## MIT 1.3.1.4 pataisymai

- Šeimos portfelis dabar skaičiuojamas griežtai:
  - `family = PORT_MARIUS + PORT_WIFE`
- Portfolio Assignment rodo formulę:
  - Marius suma + Žmonos suma = Šeimos suma.
- Portfolio lange šeimos režime rodoma bendra suma virš lentelės.


## MIT 1.3.1.5 pataisymai

- Šeimos portfelio lentelėje tos pačios pozicijos dabar sujungiamos pagal canonical ticker.
- Pvz. Marius TDIV + Žmona TDIV = viena TDIV eilutė šeimos vaizde.
- Pridėtas `Sources` stulpelis, rodantis kiek pozicijos vertės ateina iš Marius ir Žmonos portfelių.
- Atskiruose Marius / Žmona vaizduose pozicijos lieka atskirai.


## MIT 1.3.2.2 — Safe Dividend Add-on

Ši versija sukurta ant paskutinės vartotojo patvirtintos veikiančios bazės `MIT 1.3.1.5`.

Svarbu:
- Portfolio / Sync Center importo sistema nepakeista.
- Dividend Engine pridėtas kaip atskiras meniu punktas.
- Dividend History CSV importuojamas per Dividend Engine puslapį.
- Importas inkrementinis: tas pats įrašas antrą kartą nepridedamas.


## MIT 1.3.2.3 — Dividend Import Diagnostics & Portfolio Key Fix

Pataisyta:
- Dividend unique key dabar aiškiai įtraukia portfelį:
  `portfolioId + isin/ticker + exDate + payDate + totalNet`.
- Pridėta Last Import Reports lentelė:
  - nuskaityta eilučių;
  - pridėta;
  - praleista kaip dublikatai;
  - invalid;
  - į kokį portfelį importuota.
- Dividend Validation rodo Marius / Žmona / Šeima dividendų eilučių split.


## MIT 1.3.2.4 — Dividend Calendar & Summary Polish

Pridėta:
- Dividend Calendar pagal `payDate`;
- Dividend by Ticker lentelė;
- gražesnė Annual Summary;
- gražesnė Monthly Summary;
- vidurkis per aktyvų dividendų mėnesį;
- palikta importo diagnostika ir dividendų validacija.

Portfolio importo sistema nepakeista.


## MIT 1.3.2.5 — Dividend Engine Final Polish

Pridėta:
- Stable Candidate status;
- bendri dividendų skaičiai: rows, tickers, years, active months;
- dviejų eilučių KPI blokas;
- aiškesnis Current View paaiškinimas;
- Stable Notes blokas.

Po šios versijos Dividend Engine laikomas užbaigtu pagrindu. Forecast / Dividend Score atidedami vėlesniems etapams.


## MIT 1.3.2.6 — Dividend History Page Fix

Pataisyta:
- Senas `Dividends / Dividend History` puslapis dabar skaito duomenis iš `dividendEngine.history`.
- Dividend Engine ir Dividends puslapiai dabar rodo tą pačią dividendų bazę.


## MIT 1.3.3.0 — Transactions Engine Core

Pridėta:
- DivvyDiary Transactions CSV importas;
- inkrementinis importas su dublikatų kontrole;
- sandorių istorija;
- Monthly Transactions;
- Transactions by Ticker;
- Import Diagnostics;
- Transaction Validation.

Portfolio ir Dividend Engine neliečiami.


## MIT 1.4.0 — Watchlist Core

Pirmas investavimo sprendimų modulis.

Pridėta:
- Watchlist puslapis;
- ticker, name, type, target price, current price, priority, risk, note;
- automatinis statusas:
  - BUY;
  - WATCH;
  - EXPENSIVE;
  - RESEARCH / HOLD;
- Watch Score;
- Add / Edit / Delete funkcijos.

Pastaba:
- Kainos kol kas įvedamos rankiniu būdu.
- Tai yra pagrindas būsimam Buy Queue, Fair Value ir Stock/ETF Analyzer.


## MIT 2.0.0 — Universe Core

Pridėta nauja MIT 2.0 architektūra:
- MIT Profile;
- Stock Universe;
- ETF Universe;
- High Risk Universe;
- Score weights;
- Research checklist struktūra;
- Moat / Financial / Valuation / Opportunity / Portfolio Fit struktūra;
- Action laukas: OPEN, ADD, HOLD, WATCH, WAIT, REDUCE.

Ši versija yra duomenų modelio pagrindas būsimiems Research Center, Score Engine, Buy Queue ir MIT Advisor moduliams.


## MIT 2.0.1.1 — Investment Card UI

Pridėta:
- Investment Card Engine;
- Overview / Research / Financials / Valuation / Thesis / History tabs;
- Quick Summary;
- Decision Summary;
- Research Complete %;
- Confidence;
- galimybė atidaryti kortelę iš Stock / ETF / High Risk Universe lentelių.

Ši versija dar nedaro automatinio scoring ar decision logic. Tai UI ir kortelės struktūros pagrindas.


## MIT 2.0.1.2 — Research Center

Pridėta:
- Research Dashboard;
- Analysis Status;
- Confidence;
- Last Review / Next Review;
- Research Checklist su Done / Date / Notes;
- Investment Thesis editor;
- Knowledge Base editor;
- Attachments struktūros pagrindas;
- Research Timeline.

Svarbu:
- Prompt langų šiame modulyje nebenaudojame.
- Visi Research duomenys saugomi Investment Card objekte.


## MIT 2.0.1.2 FIX1

Pataisyta:
- Investment Card baltas lapas dėl `richResearchPercent is not defined`.
- Pridėtas saugus Research helper fallback.
- Naujų funkcijų nepridėta — tik hotfix.


## MIT 2.0.1.2 FIX2

Pataisyta:
- Research tab;
- Thesis tab;
- History tab;
- pridėti saugūs fallback rendereriai, kad trūkstami laukai nebelaužytų Investment Card.


## MIT 2.0.1.3 — Quality Engine

Pridėta:
- naujas `Quality` tab Investment Card;
- Economic Moat;
- Financial Strength;
- Business Quality;
- Management;
- Growth Potential;
- automatinis Quality Score pagal svorius:
  - Moat 25%;
  - Financial 25%;
  - Business 20%;
  - Management 15%;
  - Growth 15%.


## MIT 2.0.1.4 — Decision Engine

Pridėta:
- Decision tab Investment Card;
- Action: OPEN / ADD / HOLD / WATCH / WAIT / REDUCE;
- Priority A/B/C;
- Portfolio Fit;
- Opportunity Score;
- Decision Score;
- Auto Decision logic;
- Manual Override;
- Reason laukas.


## MIT 2.0.2 — MIT Score Engine

Pridėta MIT Score tab, Grade, komponentai ir reguliuojami svoriai.
