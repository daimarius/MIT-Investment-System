# MIT Architecture

External Data is imported and replaceable.

MIT Intelligence is user-owned and should not be overwritten by imports.
