# MIT 1.3 Roadmap

- 1.3.0 Core Engine ✅
- 1.3.1 DivvyDiary Sync 2.0 ✅
- 1.3.2 Validation Center next
- 1.3.3 Family Office planned
