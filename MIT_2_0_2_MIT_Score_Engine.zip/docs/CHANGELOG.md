# Changelog

## MIT 1.3.1
Added DivvyDiary Sync 2.0 multi-file importer.
