# MIT 1.3.0 — Core Engine

Pirmasis MIT 1.3 branduolio leidimas.

## Esmė

- DivvyDiary = faktiniai portfelio duomenys.
- MIT = sprendimai, strategija, target, watch, score, research.

## Nauja

- External Data layer
- MIT Intelligence layer
- Sync policies
- Validation base
- MIT 1.3 roadmap
