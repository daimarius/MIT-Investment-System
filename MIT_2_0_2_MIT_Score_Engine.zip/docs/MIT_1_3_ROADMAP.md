# MIT 1.3 Roadmap

## 1.3.0 Core Engine
Architecture and data layers.

## 1.3.1 DivvyDiary Sync 2.0
All DivvyDiary CSV imports.

## 1.3.2 Validation Center
Compare MIT vs DivvyDiary.

## 1.3.3 Family Office
Robust family aggregation.
