const MIT_DATABASE = {
  "assets": [],
  "holdings": [],
  "portfolios": [
    {
      "id": "PORT_MARIUS",
      "name": "Marius",
      "owner": "Marius",
      "currency": "EUR",
      "targets": {}
    },
    {
      "id": "PORT_WIFE",
      "name": "Žmona",
      "owner": "Žmona",
      "currency": "EUR",
      "targets": {}
    }
  ],
  "brokers": [],
  "watchlists": [],
  "settings": {
    "philosophy": "",
    "rules": []
  },
  "rules": {},
  "version": "2.0.2",
  "stage": "MIT Score Engine",
  "core": {
    "version": "1.3.0",
    "architecture": "External Data + MIT Intelligence",
    "principles": [
      "DivvyDiary is the source of factual market and portfolio data.",
      "MIT is the source of strategy, targets, watchlists, scores, research and decision rules.",
      "External data can be re-imported without overwriting MIT intelligence.",
      "Family view aggregates positions by canonical ticker; individual portfolio views stay separate.",
      "Every object links by IDs, not duplicated text."
    ],
    "layers": {
      "externalData": [
        "portfolio",
        "assetAllocation",
        "sectorAllocation",
        "countryAllocation",
        "regionAllocation",
        "dividendHistory"
      ],
      "mitIntelligence": [
        "targets",
        "rules",
        "strategy",
        "watchlists",
        "scores",
        "research",
        "goals",
        "notes"
      ]
    }
  },
  "externalData": {
    "divvyDiary": {
      "portfolio": [],
      "assetAllocation": [],
      "sectorAllocation": [],
      "countryAllocation": [],
      "regionAllocation": [],
      "dividendHistory": [],
      "lastImport": null,
      "byPortfolio": {
        "PORT_MARIUS": {
          "portfolio": [],
          "assetAllocation": [],
          "sectorAllocation": [],
          "countryAllocation": [],
          "regionAllocation": [],
          "dividendHistory": [],
          "lastImport": null
        },
        "PORT_WIFE": {
          "portfolio": [],
          "assetAllocation": [],
          "sectorAllocation": [],
          "countryAllocation": [],
          "regionAllocation": [],
          "dividendHistory": [],
          "lastImport": null
        }
      }
    }
  },
  "mitIntelligence": {
    "targets": [],
    "rules": {},
    "strategy": {},
    "watchlists": [],
    "scores": [],
    "research": [],
    "goals": []
  },
  "sync": {
    "tickerAliases": {
      "ANAU": "ANAV",
      "BRK.B": "BRK-B",
      "BRK/B": "BRK-B",
      "BRKB": "BRK-B"
    },
    "brokerByTicker": {
      "ASGI": "Freedom24",
      "CEFS": "Freedom24",
      "CEF": "Freedom24",
      "BITO": "Freedom24",
      "SCHD": "Freedom24",
      "QQQI": "Freedom24",
      "FNDE": "Freedom24"
    },
    "zeroValuePolicy": "sold_or_skip",
    "familyAggregationPolicy": "aggregate_by_canonical_ticker_in_family_view",
    "percentPolicy": "DivvyDiary decimal ratios are converted to percent",
    "supportedFiles": {
      "portfolio": [
        "symbol",
        "isin",
        "quantity",
        "buyin",
        "price",
        "value",
        "dividendYield"
      ],
      "assetAllocation": [
        "id",
        "name",
        "allocation",
        "value"
      ],
      "sectorAllocation": [
        "id",
        "name",
        "allocation",
        "value"
      ],
      "countryAllocation": [
        "id",
        "name",
        "allocation",
        "value"
      ],
      "regionAllocation": [
        "id",
        "name",
        "allocation",
        "value"
      ],
      "dividendHistory": [
        "symbol",
        "isin",
        "exDate",
        "payDate",
        "amountGross",
        "amountNet",
        "totalGross",
        "totalNet"
      ]
    }
  },
  "validation": {
    "status": "not_run",
    "lastRun": null,
    "checks": [],
    "score": null
  },
  "dividendEngine": {
    "version": "1.3.2.6",
    "history": [],
    "settings": {
      "uniqueKey": "portfolioId + isin/ticker + exDate + payDate + totalNet",
      "incrementalImport": true,
      "baseCurrency": "EUR"
    },
    "lastImport": null,
    "lastImportReport": [],
    "status": "stable_candidate"
  },
  "transactionsEngine": {
    "version": "1.3.3.0",
    "source": "DivvyDiary Transactions CSV",
    "history": [],
    "settings": {
      "uniqueKey": "portfolioId + datetime + isin/ticker + type + quantity + amount",
      "incrementalImport": true,
      "baseCurrency": "EUR"
    },
    "lastImport": null,
    "lastImportReport": []
  },
  "watchlistEngine": {
    "version": "1.4.0",
    "items": [
      {
        "id": "WL_0001",
        "ticker": "VICI",
        "name": "VICI Properties",
        "type": "stock",
        "sector": "REIT",
        "targetPrice": 30,
        "currentPrice": 0,
        "currency": "USD",
        "priority": "A",
        "status": "WATCH",
        "risk": "Medium",
        "note": "REIT kandidatas, stebėti kainą ir palūkanų aplinką.",
        "createdAt": "2026-06-29"
      },
      {
        "id": "WL_0002",
        "ticker": "ZTS",
        "name": "Zoetis",
        "type": "stock",
        "sector": "Healthcare",
        "targetPrice": 150,
        "currentPrice": 0,
        "currency": "USD",
        "priority": "B",
        "status": "RESEARCH",
        "risk": "Medium",
        "note": "Healthcare growth kandidatas, reikia vertinimo ir finansų patikros.",
        "createdAt": "2026-06-29"
      },
      {
        "id": "WL_0003",
        "ticker": "ANAV",
        "name": "Avantis Global Equity UCITS ETF",
        "type": "etf",
        "sector": "Broad Market",
        "targetPrice": 0,
        "currentPrice": 0,
        "currency": "EUR",
        "priority": "A",
        "status": "HOLD",
        "risk": "Medium",
        "note": "Core ETF, pildyti pagal target svorį.",
        "createdAt": "2026-06-29"
      },
      {
        "id": "WL_0004",
        "ticker": "AVWC",
        "name": "Avantis All Country World Equity UCITS ETF",
        "type": "etf",
        "sector": "Broad Market",
        "targetPrice": 0,
        "currentPrice": 0,
        "currency": "EUR",
        "priority": "A",
        "status": "HOLD",
        "risk": "Medium",
        "note": "Core ETF, naudoti globaliai diversifikacijai.",
        "createdAt": "2026-06-29"
      },
      {
        "id": "WL_0005",
        "ticker": "RKLB",
        "name": "Rocket Lab",
        "type": "risk_stock",
        "sector": "Space",
        "targetPrice": 0,
        "currentPrice": 0,
        "currency": "USD",
        "priority": "C",
        "status": "RESEARCH",
        "risk": "High",
        "note": "Rizikingas augimo kandidatas, limituoti dydį.",
        "createdAt": "2026-06-29"
      }
    ],
    "settings": {
      "statuses": [
        "BUY",
        "WATCH",
        "EXPENSIVE",
        "HOLD",
        "RESEARCH"
      ],
      "priorities": [
        "A",
        "B",
        "C"
      ],
      "defaultCurrency": "EUR"
    }
  },
  "mitProfile": {
    "version": "2.0.0",
    "activeProfile": "Marius",
    "profiles": {
      "Marius": {
        "strategy": "Growth + quality stocks + ETF core + controlled high risk",
        "monthlyAllocation": {
          "ETF": 75,
          "Stocks": 20,
          "HighRisk": 5
        },
        "stockTargetRangeDefault": {
          "min": 1,
          "max": 3
        },
        "highRiskTargetRangeDefault": {
          "min": 0.25,
          "max": 1
        },
        "rules": [
          "ETF targets use precise weights.",
          "Stocks use target ranges, not fixed weights.",
          "High risk positions are capped strictly.",
          "Avoid FOMO and panic decisions.",
          "Prefer buying during corrections or when price reaches target zone."
        ]
      }
    }
  },
  "universeEngine": {
    "version": "2.0.0",
    "stockUniverse": [
      {
        "id": "STK_0001",
        "ticker": "CNQ",
        "name": "Canadian Natural Resources",
        "status": "Owned",
        "type": "stock",
        "sector": "Energy",
        "industry": "",
        "country": "Canada",
        "currency": "USD",
        "broker": "",
        "portfolio": {
          "owned": true,
          "positionValue": 0,
          "positionWeight": 0,
          "targetMin": 1,
          "targetMax": 3,
          "maxWeight": 5,
          "stage": "BUILDING"
        },
        "research": {
          "msnMoney": {
            "done": false,
            "date": "",
            "notes": ""
          },
          "morningstar": {
            "done": false,
            "date": "",
            "notes": ""
          },
          "guruFocus": {
            "done": false,
            "date": "",
            "notes": ""
          },
          "finviz": {
            "done": false,
            "date": "",
            "notes": ""
          },
          "trefis": {
            "done": false,
            "date": "",
            "notes": ""
          },
          "divvyDiary": {
            "done": true,
            "date": "",
            "notes": ""
          },
          "annualReport": {
            "done": false,
            "date": "",
            "notes": ""
          },
          "earnings": {
            "done": false,
            "date": "",
            "notes": ""
          },
          "investorPresentation": {
            "done": false,
            "date": "",
            "notes": ""
          }
        },
        "moat": {
          "brand": 0,
          "switchingCosts": 0,
          "networkEffect": 0,
          "costAdvantage": 0,
          "scale": 0,
          "patents": 0,
          "regulatory": 0,
          "score": 0
        },
        "financials": {
          "revenueGrowth": 0,
          "epsGrowth": 0,
          "fcf": 0,
          "roe": 0,
          "roic": 0,
          "grossMargin": 0,
          "operatingMargin": 0,
          "netMargin": 0,
          "debtEquity": 0,
          "interestCoverage": 0,
          "score": 0
        },
        "valuation": {
          "pe": 0,
          "forwardPe": 0,
          "peg": 0,
          "evEbitda": 0,
          "priceFcf": 0,
          "fairValue": 0,
          "marginOfSafety": 0,
          "score": 0
        },
        "opportunity": {
          "targetPrice": 0,
          "currentPrice": 0,
          "ath": 0,
          "correction": 0,
          "entryZone": "WATCH",
          "score": 0
        },
        "scores": {
          "quality": 0,
          "moat": 0,
          "financial": 0,
          "valuation": 0,
          "portfolioFit": 0,
          "opportunity": 0,
          "mit": 0
        },
        "action": "ADD",
        "conviction": 0,
        "thesis": "",
        "risks": "",
        "notes": "",
        "analysisStatus": "In Progress",
        "confidence": 0,
        "history": [],
        "knowledge": {
          "business": "",
          "competitiveAdvantages": "",
          "risks": "",
          "catalysts": "",
          "whyOwn": "",
          "whySell": "",
          "lessonsLearned": ""
        },
        "createdAt": "2026-06-29",
        "lastReview": "",
        "nextReview": "",
        "attachments": [],
        "researchTimeline": [],
        "thesisDetails": {
          "whyBuy": "",
          "whyNow": "",
          "advantages": "",
          "risks": "",
          "whatWouldChangeMind": ""
        },
        "qualityEngine": {
          "weights": {
            "moat": 25,
            "financial": 25,
            "business": 20,
            "management": 15,
            "growth": 15
          },
          "business": {
            "understandableBusiness": 0,
            "durableDemand": 0,
            "pricingPower": 0,
            "businessModel": 0,
            "cyclicality": 0,
            "score": 0,
            "notes": ""
          },
          "management": {
            "capitalAllocation": 0,
            "buybacks": 0,
            "dividendPolicy": 0,
            "insiderOwnership": 0,
            "communication": 0,
            "score": 0,
            "notes": ""
          },
          "growth": {
            "tam": 0,
            "innovation": 0,
            "expansion": 0,
            "newProducts": 0,
            "international": 0,
            "score": 0,
            "notes": ""
          },
          "summary": {
            "moatScore": 0,
            "financialScore": 0,
            "businessScore": 0,
            "managementScore": 0,
            "growthScore": 0,
            "qualityScore": 0
          }
        },
        "decisionEngine": {
          "priority": "B",
          "portfolioFit": 50,
          "opportunityScore": 50,
          "decisionScore": 50,
          "action": "ADD",
          "reason": "",
          "manualOverride": false
        },
        "mitScoreEngine": {
          "weights": {
            "quality": 35,
            "decision": 25,
            "research": 15,
            "confidence": 10,
            "portfolioFit": 10,
            "opportunity": 5
          },
          "components": {
            "quality": 0,
            "decision": 0,
            "research": 0,
            "confidence": 0,
            "portfolioFit": 0,
            "opportunity": 0
          },
          "score": 0,
          "grade": "F",
          "comment": ""
        }
      },
      {
        "id": "STK_0002",
        "ticker": "ZTS",
        "name": "Zoetis",
        "status": "Candidate",
        "type": "stock",
        "sector": "Healthcare",
        "industry": "",
        "country": "US",
        "currency": "USD",
        "broker": "",
        "portfolio": {
          "owned": false,
          "positionValue": 0,
          "positionWeight": 0,
          "targetMin": 1,
          "targetMax": 3,
          "maxWeight": 5,
          "stage": "NEW"
        },
        "research": {
          "msnMoney": {
            "done": false,
            "date": "",
            "notes": ""
          },
          "morningstar": {
            "done": false,
            "date": "",
            "notes": ""
          },
          "guruFocus": {
            "done": false,
            "date": "",
            "notes": ""
          },
          "finviz": {
            "done": false,
            "date": "",
            "notes": ""
          },
          "trefis": {
            "done": false,
            "date": "",
            "notes": ""
          },
          "divvyDiary": {
            "done": false,
            "date": "",
            "notes": ""
          },
          "annualReport": {
            "done": false,
            "date": "",
            "notes": ""
          },
          "earnings": {
            "done": false,
            "date": "",
            "notes": ""
          },
          "investorPresentation": {
            "done": false,
            "date": "",
            "notes": ""
          }
        },
        "moat": {
          "brand": 0,
          "switchingCosts": 0,
          "networkEffect": 0,
          "costAdvantage": 0,
          "scale": 0,
          "patents": 0,
          "regulatory": 0,
          "score": 0
        },
        "financials": {
          "revenueGrowth": 0,
          "epsGrowth": 0,
          "fcf": 0,
          "roe": 0,
          "roic": 0,
          "grossMargin": 0,
          "operatingMargin": 0,
          "netMargin": 0,
          "debtEquity": 0,
          "interestCoverage": 0,
          "score": 0
        },
        "valuation": {
          "pe": 0,
          "forwardPe": 0,
          "peg": 0,
          "evEbitda": 0,
          "priceFcf": 0,
          "fairValue": 0,
          "marginOfSafety": 0,
          "score": 0
        },
        "opportunity": {
          "targetPrice": 150,
          "currentPrice": 0,
          "ath": 0,
          "correction": 0,
          "entryZone": "WATCH",
          "score": 0
        },
        "scores": {
          "quality": 0,
          "moat": 0,
          "financial": 0,
          "valuation": 0,
          "portfolioFit": 0,
          "opportunity": 0,
          "mit": 0
        },
        "action": "WATCH",
        "conviction": 0,
        "thesis": "Healthcare growth candidate.",
        "risks": "",
        "notes": "",
        "analysisStatus": "New Idea",
        "confidence": 0,
        "history": [],
        "knowledge": {
          "business": "",
          "competitiveAdvantages": "",
          "risks": "",
          "catalysts": "",
          "whyOwn": "",
          "whySell": "",
          "lessonsLearned": ""
        },
        "createdAt": "2026-06-29",
        "lastReview": "",
        "nextReview": "",
        "attachments": [],
        "researchTimeline": [],
        "thesisDetails": {
          "whyBuy": "Healthcare growth candidate.",
          "whyNow": "",
          "advantages": "",
          "risks": "",
          "whatWouldChangeMind": ""
        },
        "qualityEngine": {
          "weights": {
            "moat": 25,
            "financial": 25,
            "business": 20,
            "management": 15,
            "growth": 15
          },
          "business": {
            "understandableBusiness": 0,
            "durableDemand": 0,
            "pricingPower": 0,
            "businessModel": 0,
            "cyclicality": 0,
            "score": 0,
            "notes": ""
          },
          "management": {
            "capitalAllocation": 0,
            "buybacks": 0,
            "dividendPolicy": 0,
            "insiderOwnership": 0,
            "communication": 0,
            "score": 0,
            "notes": ""
          },
          "growth": {
            "tam": 0,
            "innovation": 0,
            "expansion": 0,
            "newProducts": 0,
            "international": 0,
            "score": 0,
            "notes": ""
          },
          "summary": {
            "moatScore": 0,
            "financialScore": 0,
            "businessScore": 0,
            "managementScore": 0,
            "growthScore": 0,
            "qualityScore": 0
          }
        },
        "decisionEngine": {
          "priority": "B",
          "portfolioFit": 50,
          "opportunityScore": 50,
          "decisionScore": 50,
          "action": "WATCH",
          "reason": "",
          "manualOverride": false
        },
        "mitScoreEngine": {
          "weights": {
            "quality": 35,
            "decision": 25,
            "research": 15,
            "confidence": 10,
            "portfolioFit": 10,
            "opportunity": 5
          },
          "components": {
            "quality": 0,
            "decision": 0,
            "research": 0,
            "confidence": 0,
            "portfolioFit": 0,
            "opportunity": 0
          },
          "score": 0,
          "grade": "F",
          "comment": ""
        }
      }
    ],
    "etfUniverse": [
      {
        "id": "ETF_0001",
        "ticker": "ANAV",
        "name": "Avantis Global Equity UCITS ETF",
        "status": "Owned",
        "category": "Core",
        "purpose": "Core Growth",
        "ucits": true,
        "ter": 0,
        "accDist": "Acc",
        "region": "Global",
        "factor": "Broad Market",
        "currency": "EUR",
        "broker": "Trading212",
        "portfolio": {
          "owned": true,
          "positionValue": 0,
          "positionWeight": 0,
          "targetWeight": 10,
          "stage": "BUILDING"
        },
        "scores": {
          "cost": 0,
          "diversification": 0,
          "portfolioFit": 0,
          "opportunity": 0,
          "mit": 0
        },
        "action": "ADD",
        "notes": "Core ETF.",
        "analysisStatus": "In Progress",
        "confidence": 0,
        "history": [],
        "knowledge": {
          "business": "",
          "competitiveAdvantages": "",
          "risks": "",
          "catalysts": "",
          "whyOwn": "",
          "whySell": "",
          "lessonsLearned": ""
        },
        "createdAt": "2026-06-29",
        "lastReview": "",
        "nextReview": "",
        "attachments": [],
        "researchTimeline": [],
        "research": {
          "msnMoney": {
            "done": false,
            "date": "",
            "notes": ""
          },
          "morningstar": {
            "done": false,
            "date": "",
            "notes": ""
          },
          "guruFocus": {
            "done": false,
            "date": "",
            "notes": ""
          },
          "finviz": {
            "done": false,
            "date": "",
            "notes": ""
          },
          "trefis": {
            "done": false,
            "date": "",
            "notes": ""
          },
          "divvyDiary": {
            "done": false,
            "date": "",
            "notes": ""
          },
          "annualReport": {
            "done": false,
            "date": "",
            "notes": ""
          },
          "earnings": {
            "done": false,
            "date": "",
            "notes": ""
          },
          "investorPresentation": {
            "done": false,
            "date": "",
            "notes": ""
          }
        },
        "thesisDetails": {
          "whyBuy": "",
          "whyNow": "",
          "advantages": "",
          "risks": "",
          "whatWouldChangeMind": ""
        },
        "qualityEngine": {
          "weights": {
            "moat": 25,
            "financial": 25,
            "business": 20,
            "management": 15,
            "growth": 15
          },
          "business": {
            "understandableBusiness": 0,
            "durableDemand": 0,
            "pricingPower": 0,
            "businessModel": 0,
            "cyclicality": 0,
            "score": 0,
            "notes": ""
          },
          "management": {
            "capitalAllocation": 0,
            "buybacks": 0,
            "dividendPolicy": 0,
            "insiderOwnership": 0,
            "communication": 0,
            "score": 0,
            "notes": ""
          },
          "growth": {
            "tam": 0,
            "innovation": 0,
            "expansion": 0,
            "newProducts": 0,
            "international": 0,
            "score": 0,
            "notes": ""
          },
          "summary": {
            "moatScore": 0,
            "financialScore": 0,
            "businessScore": 0,
            "managementScore": 0,
            "growthScore": 0,
            "qualityScore": 0
          }
        },
        "moat": {
          "brand": 0,
          "switchingCosts": 0,
          "networkEffect": 0,
          "costAdvantage": 0,
          "scale": 0,
          "patents": 0,
          "regulatory": 0,
          "score": 0
        },
        "financials": {
          "revenueGrowth": 0,
          "epsGrowth": 0,
          "fcf": 0,
          "roe": 0,
          "roic": 0,
          "grossMargin": 0,
          "operatingMargin": 0,
          "netMargin": 0,
          "debtEquity": 0,
          "interestCoverage": 0,
          "score": 0
        },
        "decisionEngine": {
          "priority": "B",
          "portfolioFit": 50,
          "opportunityScore": 50,
          "decisionScore": 50,
          "action": "ADD",
          "reason": "",
          "manualOverride": false
        },
        "mitScoreEngine": {
          "weights": {
            "quality": 35,
            "decision": 25,
            "research": 15,
            "confidence": 10,
            "portfolioFit": 10,
            "opportunity": 5
          },
          "components": {
            "quality": 0,
            "decision": 0,
            "research": 0,
            "confidence": 0,
            "portfolioFit": 0,
            "opportunity": 0
          },
          "score": 0,
          "grade": "F",
          "comment": ""
        }
      },
      {
        "id": "ETF_0002",
        "ticker": "AVWC",
        "name": "Avantis All Country World Equity UCITS ETF",
        "status": "Owned",
        "category": "Core",
        "purpose": "Core Global",
        "ucits": true,
        "ter": 0,
        "accDist": "Acc",
        "region": "Global",
        "factor": "Broad Market",
        "currency": "EUR",
        "broker": "Trading212",
        "portfolio": {
          "owned": true,
          "positionValue": 0,
          "positionWeight": 0,
          "targetWeight": 10,
          "stage": "BUILDING"
        },
        "scores": {
          "cost": 0,
          "diversification": 0,
          "portfolioFit": 0,
          "opportunity": 0,
          "mit": 0
        },
        "action": "ADD",
        "notes": "Core ETF.",
        "analysisStatus": "In Progress",
        "confidence": 0,
        "history": [],
        "knowledge": {
          "business": "",
          "competitiveAdvantages": "",
          "risks": "",
          "catalysts": "",
          "whyOwn": "",
          "whySell": "",
          "lessonsLearned": ""
        },
        "createdAt": "2026-06-29",
        "lastReview": "",
        "nextReview": "",
        "attachments": [],
        "researchTimeline": [],
        "research": {
          "msnMoney": {
            "done": false,
            "date": "",
            "notes": ""
          },
          "morningstar": {
            "done": false,
            "date": "",
            "notes": ""
          },
          "guruFocus": {
            "done": false,
            "date": "",
            "notes": ""
          },
          "finviz": {
            "done": false,
            "date": "",
            "notes": ""
          },
          "trefis": {
            "done": false,
            "date": "",
            "notes": ""
          },
          "divvyDiary": {
            "done": false,
            "date": "",
            "notes": ""
          },
          "annualReport": {
            "done": false,
            "date": "",
            "notes": ""
          },
          "earnings": {
            "done": false,
            "date": "",
            "notes": ""
          },
          "investorPresentation": {
            "done": false,
            "date": "",
            "notes": ""
          }
        },
        "thesisDetails": {
          "whyBuy": "",
          "whyNow": "",
          "advantages": "",
          "risks": "",
          "whatWouldChangeMind": ""
        },
        "qualityEngine": {
          "weights": {
            "moat": 25,
            "financial": 25,
            "business": 20,
            "management": 15,
            "growth": 15
          },
          "business": {
            "understandableBusiness": 0,
            "durableDemand": 0,
            "pricingPower": 0,
            "businessModel": 0,
            "cyclicality": 0,
            "score": 0,
            "notes": ""
          },
          "management": {
            "capitalAllocation": 0,
            "buybacks": 0,
            "dividendPolicy": 0,
            "insiderOwnership": 0,
            "communication": 0,
            "score": 0,
            "notes": ""
          },
          "growth": {
            "tam": 0,
            "innovation": 0,
            "expansion": 0,
            "newProducts": 0,
            "international": 0,
            "score": 0,
            "notes": ""
          },
          "summary": {
            "moatScore": 0,
            "financialScore": 0,
            "businessScore": 0,
            "managementScore": 0,
            "growthScore": 0,
            "qualityScore": 0
          }
        },
        "moat": {
          "brand": 0,
          "switchingCosts": 0,
          "networkEffect": 0,
          "costAdvantage": 0,
          "scale": 0,
          "patents": 0,
          "regulatory": 0,
          "score": 0
        },
        "financials": {
          "revenueGrowth": 0,
          "epsGrowth": 0,
          "fcf": 0,
          "roe": 0,
          "roic": 0,
          "grossMargin": 0,
          "operatingMargin": 0,
          "netMargin": 0,
          "debtEquity": 0,
          "interestCoverage": 0,
          "score": 0
        },
        "decisionEngine": {
          "priority": "B",
          "portfolioFit": 50,
          "opportunityScore": 50,
          "decisionScore": 50,
          "action": "ADD",
          "reason": "",
          "manualOverride": false
        },
        "mitScoreEngine": {
          "weights": {
            "quality": 35,
            "decision": 25,
            "research": 15,
            "confidence": 10,
            "portfolioFit": 10,
            "opportunity": 5
          },
          "components": {
            "quality": 0,
            "decision": 0,
            "research": 0,
            "confidence": 0,
            "portfolioFit": 0,
            "opportunity": 0
          },
          "score": 0,
          "grade": "F",
          "comment": ""
        }
      }
    ],
    "highRiskUniverse": [
      {
        "id": "RISK_0001",
        "ticker": "RKLB",
        "name": "Rocket Lab",
        "status": "Candidate",
        "sector": "Space",
        "theme": "Space economy",
        "currency": "USD",
        "portfolio": {
          "owned": false,
          "positionValue": 0,
          "positionWeight": 0,
          "targetMin": 0.25,
          "targetMax": 1,
          "maxWeight": 1,
          "stage": "NEW"
        },
        "risk": {
          "level": "High",
          "cashBurn": "",
          "profitabilityEta": "",
          "dilutionRisk": 0,
          "technologyRisk": 0,
          "score": 0
        },
        "catalysts": "",
        "exitPlan": "",
        "action": "WATCH",
        "conviction": 0,
        "notes": "High risk idea.",
        "analysisStatus": "New Idea",
        "confidence": 0,
        "history": [],
        "knowledge": {
          "business": "",
          "competitiveAdvantages": "",
          "risks": "",
          "catalysts": "",
          "whyOwn": "",
          "whySell": "",
          "lessonsLearned": ""
        },
        "createdAt": "2026-06-29",
        "lastReview": "",
        "nextReview": "",
        "attachments": [],
        "researchTimeline": [],
        "research": {
          "msnMoney": {
            "done": false,
            "date": "",
            "notes": ""
          },
          "morningstar": {
            "done": false,
            "date": "",
            "notes": ""
          },
          "guruFocus": {
            "done": false,
            "date": "",
            "notes": ""
          },
          "finviz": {
            "done": false,
            "date": "",
            "notes": ""
          },
          "trefis": {
            "done": false,
            "date": "",
            "notes": ""
          },
          "divvyDiary": {
            "done": false,
            "date": "",
            "notes": ""
          },
          "annualReport": {
            "done": false,
            "date": "",
            "notes": ""
          },
          "earnings": {
            "done": false,
            "date": "",
            "notes": ""
          },
          "investorPresentation": {
            "done": false,
            "date": "",
            "notes": ""
          }
        },
        "thesisDetails": {
          "whyBuy": "",
          "whyNow": "",
          "advantages": "",
          "risks": "",
          "whatWouldChangeMind": ""
        },
        "qualityEngine": {
          "weights": {
            "moat": 25,
            "financial": 25,
            "business": 20,
            "management": 15,
            "growth": 15
          },
          "business": {
            "understandableBusiness": 0,
            "durableDemand": 0,
            "pricingPower": 0,
            "businessModel": 0,
            "cyclicality": 0,
            "score": 0,
            "notes": ""
          },
          "management": {
            "capitalAllocation": 0,
            "buybacks": 0,
            "dividendPolicy": 0,
            "insiderOwnership": 0,
            "communication": 0,
            "score": 0,
            "notes": ""
          },
          "growth": {
            "tam": 0,
            "innovation": 0,
            "expansion": 0,
            "newProducts": 0,
            "international": 0,
            "score": 0,
            "notes": ""
          },
          "summary": {
            "moatScore": 0,
            "financialScore": 0,
            "businessScore": 0,
            "managementScore": 0,
            "growthScore": 0,
            "qualityScore": 0
          }
        },
        "moat": {
          "brand": 0,
          "switchingCosts": 0,
          "networkEffect": 0,
          "costAdvantage": 0,
          "scale": 0,
          "patents": 0,
          "regulatory": 0,
          "score": 0
        },
        "financials": {
          "revenueGrowth": 0,
          "epsGrowth": 0,
          "fcf": 0,
          "roe": 0,
          "roic": 0,
          "grossMargin": 0,
          "operatingMargin": 0,
          "netMargin": 0,
          "debtEquity": 0,
          "interestCoverage": 0,
          "score": 0
        },
        "decisionEngine": {
          "priority": "B",
          "portfolioFit": 50,
          "opportunityScore": 50,
          "decisionScore": 50,
          "action": "WATCH",
          "reason": "",
          "manualOverride": false
        },
        "mitScoreEngine": {
          "weights": {
            "quality": 35,
            "decision": 25,
            "research": 15,
            "confidence": 10,
            "portfolioFit": 10,
            "opportunity": 5
          },
          "components": {
            "quality": 0,
            "decision": 0,
            "research": 0,
            "confidence": 0,
            "portfolioFit": 0,
            "opportunity": 0
          },
          "score": 0,
          "grade": "F",
          "comment": ""
        }
      }
    ],
    "scoreWeights": {
      "stock": {
        "moat": 20,
        "financial": 20,
        "valuation": 20,
        "portfolioFit": 20,
        "opportunity": 20
      },
      "etf": {
        "cost": 20,
        "diversification": 30,
        "portfolioFit": 30,
        "opportunity": 20
      },
      "highRisk": {
        "thesis": 25,
        "catalyst": 25,
        "riskControl": 25,
        "opportunity": 25
      }
    }
  },
  "investmentCardEngine": {
    "version": "2.0.1.1",
    "tabs": [
      "Overview",
      "Research",
      "Financials",
      "Valuation",
      "Thesis",
      "History"
    ],
    "status": "ui_core"
  },
  "researchCenterEngine": {
    "version": "2.0.1.2",
    "sources": [
      "msnMoney",
      "morningstar",
      "guruFocus",
      "finviz",
      "trefis",
      "divvyDiary",
      "annualReport",
      "earnings",
      "investorPresentation"
    ],
    "statuses": [
      "New Idea",
      "In Progress",
      "Complete",
      "Archived"
    ]
  }
};