
let db=JSON.parse(localStorage.getItem("mit_2_0_2_fix2"))||MIT_DATABASE;
let page="sync", view="family";
let syncLog=[];
const app=document.getElementById("app");
const colors=["#2563eb","#16a34a","#ca8a04","#7c3aed","#dc2626","#0891b2","#4f46e5","#9333ea"];

function euro(n){return new Intl.NumberFormat("lt-LT",{style:"currency",currency:"EUR"}).format(Number(n||0))}
function pct(n){return (Number(n||0)).toFixed(2)+"%"}
function a(id){return (db.assets||[]).find(x=>x.id===id)||{}}
function b(id){return (db.brokers||[]).find(x=>x.id===id)||{}}
function p(id){return (db.portfolios||[]).find(x=>x.id===id)||{}}
function forcePortfolios(){
  db.portfolios=[
    {id:"PORT_MARIUS",name:"Marius",owner:"Marius",currency:"EUR",targets:{}},
    {id:"PORT_WIFE",name:"Žmona",owner:"Žmona",currency:"EUR",targets:{}}
  ];
  db.externalData=db.externalData||{};
  db.externalData.divvyDiary=db.externalData.divvyDiary||{};
  db.externalData.divvyDiary.byPortfolio=db.externalData.divvyDiary.byPortfolio||{};
  ["PORT_MARIUS","PORT_WIFE"].forEach(id=>{
    if(!db.externalData.divvyDiary.byPortfolio[id]){
      db.externalData.divvyDiary.byPortfolio[id]={portfolio:[],assetAllocation:[],sectorAllocation:[],countryAllocation:[],regionAllocation:[],dividendHistory:[],lastImport:null};
    }
  });
}
function activeHoldings(){
  return (db.holdings||[]).filter(h=>h.status!=="sold" && Number(h.currentValue||0)>0);
}
function holdingsByPortfolio(portId){
  return activeHoldings().filter(h=>h.portfolioId===portId);
}
function familyHoldingsRaw(){
  // Family raw = Marius + Žmona active positions
  return [...holdingsByPortfolio("PORT_MARIUS"), ...holdingsByPortfolio("PORT_WIFE")];
}
function familyHoldingsAggregated(){
  // Family display = merge same canonical ticker into one row
  let map={};
  familyHoldingsRaw().forEach(h=>{
    let aa=a(h.assetId);
    let key=canonicalTicker(aa.ticker || aa.isin || h.assetId);
    if(!map[key]){
      map[key]={
        id:"FAMILY_"+key,
        assetId:h.assetId,
        portfolioId:"family",
        brokerId:"MULTI",
        currentValue:0,
        quantity:0,
        investedCapital:0,
        annualDividendRate:0,
        targetWeight:0,
        status:"active",
        source:"FamilyAggregated",
        sources:[]
      };
    }
    map[key].currentValue += Number(h.currentValue||0);
    map[key].quantity += Number(h.quantity||0);
    map[key].investedCapital += Number(h.investedCapital||0);
    map[key].annualDividendRate += Number(h.annualDividendRate||0);
    map[key].targetWeight += Number(h.targetWeight||0);
    map[key].sources.push({
      portfolioId:h.portfolioId,
      brokerId:h.brokerId,
      value:Number(h.currentValue||0),
      quantity:Number(h.quantity||0)
    });
  });
  return Object.values(map);
}
function displayHoldings(){
  return view==="family" ? familyHoldingsAggregated() : hs();
}
function brokerLabelForHolding(h){
  if(h.brokerId==="MULTI" || h.source==="FamilyAggregated"){
    let names=[...new Set((h.sources||[]).map(s=>b(s.brokerId).name).filter(Boolean))];
    return names.length>1 ? "Multiple" : (names[0]||"");
  }
  return b(h.brokerId).name||"";
}
function portfolioLabelForHolding(h){
  if(h.portfolioId==="family" || h.source==="FamilyAggregated"){
    return "Šeima";
  }
  return p(h.portfolioId).name||"";
}
function sourceLabelForHolding(h){
  if(!h.sources) return "-";
  return h.sources.map(s=>`${p(s.portfolioId).name||""}: ${euro(s.value)}`).join("<br>");
}
function hs(){
  if(view==="family") return familyHoldingsRaw();
  return holdingsByPortfolio(view);
}
function hv(h){return Number(h.currentValue||0)}
function inc(h){
  let aa=a(h.assetId);
  return h.annualDividendRate ? Number(h.annualDividendRate) : hv(h)*Number(aa.dividendYield||0)/100;
}
function total(list){
  let arr = list || hs();
  return arr.reduce((s,h)=>s+hv(h),0);
}
function income(list){
  let arr = list || hs();
  return arr.reduce((s,h)=>s+inc(h),0);
}
function familyTotal(){return total(familyHoldingsRaw())}
function familyIncome(){return income(familyHoldingsRaw())}
function setPage(x){page=x;render()} 
function setView(x){view=x;renderPage()}
function save(){localStorage.setItem("mit_2_0_2_fix2",JSON.stringify(db));render()}
function nav(x,l){return `<button class="nav ${page===x?'active':''}" onclick="setPage('${x}')">${l}</button>`}
function viewSelect(){
  forcePortfolios();
  return `<select class="input" onchange="setView(this.value)">
    <option value="family" ${view==="family"?"selected":""}>Šeima</option>
    <option value="PORT_MARIUS" ${view==="PORT_MARIUS"?"selected":""}>Marius</option>
    <option value="PORT_WIFE" ${view==="PORT_WIFE"?"selected":""}>Žmona</option>
  </select>`;
}
function shell(){return `<div class="app"><aside class="side"><div class="brand"><div class="logo">MIT</div><div><h1>Marius Investment Terminal</h1><p>2.0.2 MIT Score Engine</p></div></div><div class="nav-title">Sync</div>${nav("sync","🔄 Sync Center")}${nav("dividendEngine","💰 Dividend Engine")}${nav("transactionsEngine","🧾 Transactions Engine")}${nav("external","📥 External Data")}${nav("dividends","💰 Dividends")}${nav("summary","📋 Sync Summary")}<div class="nav-title">MIT 2.0</div>${nav("universe","🧠 Universe Core")}${nav("investmentCard","🧾 Investment Card")}${nav("stockUniverse","⭐ Stock Universe")}${nav("etfUniverse","📊 ETF Universe")}${nav("highRiskUniverse","🚀 High Risk Universe")}<div class="nav-title">Analyzer</div>${nav("watchlist","⭐ Watchlist")}<div class="nav-title">Preview</div>${nav("portfolio","💼 Portfolio")}${nav("analytics","📊 Analytics")}${nav("validation","✅ Validation Prep")}<div class="nav-title">System</div>${nav("settings","⚙ Settings")}</aside><main class="main"><header class="top"><div><h2>${title()}</h2><p>${subtitle()}</p></div><div class="actions">${viewSelect()}<button class="btn green" onclick="exportDb()">Export JSON</button><label class="upload">Restore JSON<input type="file" accept=".json" onchange="importDb(event)"></label><button class="btn secondary" onclick="resetLocal()">Reset Local</button></div></header><div id="root"></div></main></div>`}
function title(){return {sync:"DivvyDiary Sync 2.0",external:"External Data Layer",dividends:"Dividend History",summary:"Sync Summary",portfolio:"Portfolio Preview",analytics:"Analytics Preview",validation:"Validation Preparation",settings:"Settings"}[page]||"MIT"}
function subtitle(){return {sync:"Marius importas visada eina tik į PORT_MARIUS, Žmona importas visada tik į PORT_WIFE.",external:"External Data atskirta pagal fiksuotą portfelio ID.",dividends:"Dividendai rodomi pagal pasirinktą portfelį arba šeimą."}[page]||"MIT 2.0.2 FIX2"}
function render(){forcePortfolios();app.innerHTML=shell();renderPage()}
function renderPage(){document.getElementById("root").innerHTML=({investmentCard:InvestmentCard,universe:UniverseDashboard,stockUniverse:StockUniverse,etfUniverse:ETFUniverse,highRiskUniverse:HighRiskUniverse,watchlist:Watchlist,sync:Sync,dividendEngine:DividendEngine,transactionsEngine:TransactionsEngine,external:External,dividends:Dividends,summary:Summary,portfolio:Portfolio,analytics:Analytics,validation:Validation,settings:Settings}[page]||Sync)()}

function parseNumber(v){if(v===undefined||v===null)return 0;let s=String(v).trim().replace("%","").replace(/\s/g,"");if(!s)return 0;if(s.includes(",")&&s.includes("."))s=s.replace(/\./g,"").replace(",",".");else if(s.includes(","))s=s.replace(",",".");let n=Number(s);return isNaN(n)?0:n}
function normalizePercent(v){let n=parseNumber(v);if(Math.abs(n)>0&&Math.abs(n)<=1)return n*100;return n}
function detectDelimiter(line){let c={";":(line.match(/;/g)||[]).length,",":(line.match(/,/g)||[]).length,"\t":(line.match(/\t/g)||[]).length};if(c[";"]>=c[","]&&c[";"]>=c["\t"])return ";";if(c["\t"]>=c[","])return "\t";return ","}
function parseCsv(text){text=String(text||"").replace(/^\uFEFF/,"");let d=detectDelimiter(text.split(/\r?\n/)[0]||"");let rows=[],i=0,cur="",row=[],q=false;function ec(){row.push(cur);cur=""}function er(){ec();rows.push(row);row=[]}while(i<text.length){let ch=text[i];if(ch=='"'){if(q&&text[i+1]=='"'){cur+='"';i++}else q=!q}else if(ch===d&&!q)ec();else if((ch=="\n"||ch=="\r")&&!q){if(ch=="\r"&&text[i+1]=="\n")i++;if(cur!==""||row.length)er()}else cur+=ch;i++}if(cur!==""||row.length)er();let headers=(rows.shift()||[]).map(x=>String(x||"").trim());return rows.filter(r=>r.some(x=>String(x).trim()!="")).map(r=>{let o={};headers.forEach((h,idx)=>o[h]=r[idx]??"");return o})}
function canonicalTicker(t){let x=String(t||"").toUpperCase().trim();return (db.sync?.tickerAliases||{})[x]||x}
function nid(prefix,arr){let m=0;(arr||[]).forEach(x=>{let n=Number(String(x.id||"").replace(prefix,""));if(!isNaN(n))m=Math.max(m,n)});return prefix+String(m+1).padStart(4,"0")}
function getBrokerByTicker(t){let canon=canonicalTicker(t);let name=(db.sync?.brokerByTicker||{})[canon]||"Trading212";let br=(db.brokers||[]).find(x=>x.name===name)||(db.brokers||[])[0];return br?.id||"BROKER001"}
function normalizeType(sec,ticker){let s=String(sec||"").toLowerCase();if(s.includes("etf")||s.includes("fund"))return "etf";if(s.includes("crypto")||["BTC","BTIC","IBIT","BITO"].includes(String(ticker).toUpperCase()))return "crypto";return "stock"}
function ensureAsset(row){let raw=(row.symbol||row.ticker||row.id||"").toUpperCase().trim();let ticker=canonicalTicker(raw);if(!ticker)return null;db.assets=db.assets||[];let aa=db.assets.find(x=>canonicalTicker(x.ticker)===ticker);if(!aa){aa={id:nid("ASSET",db.assets),ticker,name:row.name||ticker,type:normalizeType(row.securityType,ticker),currency:row.currency||"EUR",status:"active"};db.assets.push(aa);syncLog.unshift(`➕ Asset sukurtas: ${ticker}`)}aa.ticker=ticker;aa.isin=row.isin||aa.isin;aa.name=row.name||aa.name;aa.currency=row.currency||aa.currency||"EUR";aa.country=row.country||aa.country;aa.region=row.region||row.country||aa.region;aa.sector=row.sector||aa.sector;aa.securityType=row.securityType||aa.securityType;aa.type=aa.type||normalizeType(row.securityType,ticker);if(row.dividendYield!==undefined&&row.dividendYield!=="")aa.dividendYield=normalizePercent(row.dividendYield);if(row.dividendCagr!==undefined&&row.dividendCagr!=="")aa.dividendCAGR=normalizePercent(row.dividendCagr);aa.dividendFrequency=row.dividendFrequency||aa.dividendFrequency;return aa}
function identifyFile(rows,name){let set=new Set(Object.keys(rows[0]||{}));let lname=String(name||"").toLowerCase();if(set.has("symbol")&&set.has("quantity")&&set.has("value"))return "portfolio";if(set.has("symbol")&&set.has("exDate")&&set.has("totalNet"))return "dividendHistory";if(set.has("id")&&set.has("allocation")&&set.has("value")){let ids=rows.map(r=>String(r.id||"")).join(" ");let names=rows.map(r=>String(r.name||"")).join(" ").toLowerCase();if(lname.includes("sector")||names.includes("technology")||names.includes("financials"))return "sectorAllocation";if(lname.includes("country")||ids.includes("US")||names.includes("belgium"))return "countryAllocation";if(lname.includes("region")||names.includes("north america")||names.includes("europe"))return "regionAllocation";return "assetAllocation"}return "unknown"}

function ext(portId){forcePortfolios();return db.externalData.divvyDiary.byPortfolio[portId]}
function clearImportedHoldings(portId){db.holdings=(db.holdings||[]).filter(h=>!(h.portfolioId===portId && h.source==="DivvyDiary"))}
function importPortfolio(rows,portId){
  let imported=0,created=0,skipped=0; db.holdings=db.holdings||[]; clearImportedHoldings(portId);
  rows.forEach(row=>{
    let aa=ensureAsset(row); if(!aa)return;
    let value=parseNumber(row.value), qty=parseNumber(row.quantity);
    if(value===0||qty===0){skipped++;return}
    let h={id:nid("HOLD",db.holdings),assetId:aa.id,portfolioId:portId,brokerId:getBrokerByTicker(aa.ticker),currentValue:value,targetWeight:0,status:"active",source:"DivvyDiary"};
    h.quantity=qty;h.averagePrice=parseNumber(row.buyin);h.investedCapital=parseNumber(row.buyinTotal);h.currentPrice=parseNumber(row.price);h.gain=parseNumber(row.gain);h.gainRel=normalizePercent(row.gainRel);h.divvyAllocation=normalizePercent(row.allocation);h.yieldOnCost=normalizePercent(row.dividendYieldOnBuyin);h.annualDividendRate=parseNumber(row.totalDividendRate);h.lastUpdate=new Date().toISOString().slice(0,10);
    db.holdings.push(h); imported++; created++;
  });
  ext(portId).portfolio=rows; ext(portId).lastImport=new Date().toISOString();
  return {imported,created,skipped};
}
function importAllocation(type,rows,portId){ext(portId)[type]=rows.map(r=>({id:r.id||"",name:r.name||"",allocation:normalizePercent(r.allocation),value:parseNumber(r.value)}));ext(portId).lastImport=new Date().toISOString();return rows.length}
function importDividends(rows,portId){ext(portId).dividendHistory=rows.map(r=>({portfolioId:portId,symbol:canonicalTicker(r.symbol),isin:r.isin||"",name:r.name||"",exDate:r.exDate||"",payDate:r.payDate||"",amountGross:parseNumber(r.amountGross),amountNet:parseNumber(r.amountNet),quantity:parseNumber(r.quantity),totalGross:parseNumber(r.totalGross),totalNet:parseNumber(r.totalNet),currency:r.currency||"",originalCurrency:r.originalCurrency||"",exchangeRate:parseNumber(r.exchangeRate),taxRate:normalizePercent(r.taxRate)}));ext(portId).lastImport=new Date().toISOString();return rows.length}
function handleFiles(event,portId){
  let files=[...event.target.files];if(!files.length)return;let pending=files.length,summary=[];
  files.forEach(file=>{let reader=new FileReader();reader.onload=e=>{let rows=parseCsv(e.target.result),type=identifyFile(rows,file.name);let owner=p(portId).name;
    if(type==="portfolio"){let res=importPortfolio(rows,portId);summary.push(`${owner} / ${file.name}: Portfolio ${res.imported} eil., naujų ${res.created}, praleista ${res.skipped}`)}
    else if(type==="dividendHistory"){let n=importDividends(rows,portId);summary.push(`${owner} / ${file.name}: Dividend History ${n} eil.`)}
    else if(["assetAllocation","sectorAllocation","countryAllocation","regionAllocation"].includes(type)){let n=importAllocation(type,rows,portId);summary.push(`${owner} / ${file.name}: ${type} ${n} eil.`)}
    else{summary.push(`${owner} / ${file.name}: neatpažintas failas`)}
    pending--; if(pending===0){syncLog=[...summary,...syncLog];save()}
  };reader.readAsText(file)});
}
function dividendRowsForView(v=view){if(v==="family")return [...(ext("PORT_MARIUS").dividendHistory||[]),...(ext("PORT_WIFE").dividendHistory||[])];return ext(v).dividendHistory||[]}
function portfolioAssignmentTable(){
  let row=(id)=>{
    let list=holdingsByPortfolio(id);
    return `<tr><td>${p(id).name}</td><td>${id}</td><td>${list.length}</td><td>${euro(total(list))}</td><td>${euro(income(list))}</td><td>${(ext(id).dividendHistory||[]).length}</td></tr>`;
  };
  let m=holdingsByPortfolio("PORT_MARIUS");
  let w=holdingsByPortfolio("PORT_WIFE");
  let fam=familyHoldingsRaw();
  return `<table><thead><tr><th>Portfolio</th><th>ID</th><th>Positions</th><th>Value</th><th>Income est.</th><th>Dividend rows</th></tr></thead><tbody>
    ${row("PORT_MARIUS")}
    ${row("PORT_WIFE")}
    <tr><td><strong>Šeima</strong></td><td>PORT_MARIUS + PORT_WIFE</td><td>${fam.length}</td><td>${euro(total(m)+total(w))}</td><td>${euro(income(m)+income(w))}</td><td>${dividendRowsForView("family").length}</td></tr>
  </tbody></table>
  <div class="alert ok">Šeima = Marius ${euro(total(m))} + Žmona ${euro(total(w))} = ${euro(total(m)+total(w))}</div>`;
}



function dividendHistory(){
  db.dividendEngine=db.dividendEngine||{history:[],settings:{},lastImport:null,lastImportReport:[]};
  db.dividendEngine.history=db.dividendEngine.history||[];
  db.dividendEngine.lastImportReport=db.dividendEngine.lastImportReport||[];
  return db.dividendEngine.history;
}
function normalizeDateValue(v){
  return String(v||"").trim().slice(0,10);
}
function dividendKey(portfolioId,row){
  let isin=String(row.isin||"").trim().toUpperCase();
  let symbol=canonicalTicker(row.symbol||"");
  let ex=normalizeDateValue(row.exDate);
  let pay=normalizeDateValue(row.payDate);
  let net=parseNumber(row.totalNet).toFixed(6);
  // include portfolioId and totalNet to avoid cross-portfolio false duplicates and catch same ISIN/date different payout
  return [portfolioId, isin||symbol, ex, pay, net].join("|");
}
function importDividendHistoryCore(rows,portId){
  let hist=dividendHistory();
  let existing=new Set(hist.map(x=>x.key));
  let added=0, skipped=0, invalid=0;
  let examples=[];
  rows.forEach((r,idx)=>{
    let hasRequired=(r.symbol||r.isin) && (r.exDate||r.payDate) && (r.totalNet!==undefined && r.totalNet!=="");
    if(!hasRequired){invalid++; if(examples.length<5)examples.push(`eil.${idx+1}: trūksta required laukų`); return;}
    let key=dividendKey(portId,r);
    if(existing.has(key)){skipped++; return;}
    let entry={
      id:"DIV_"+String(hist.length+1).padStart(6,"0"),
      key,
      portfolioId:portId,
      isin:r.isin||"",
      ticker:canonicalTicker(r.symbol||""),
      name:r.name||"",
      exDate:normalizeDateValue(r.exDate),
      payDate:normalizeDateValue(r.payDate),
      quantity:parseNumber(r.quantity),
      amountGross:parseNumber(r.amountGross),
      amountNet:parseNumber(r.amountNet),
      totalGross:parseNumber(r.totalGross),
      totalNet:parseNumber(r.totalNet),
      currency:r.currency||"",
      originalCurrency:r.originalCurrency||"",
      exchangeRate:parseNumber(r.exchangeRate),
      taxRate:normalizePercent(r.taxRate),
      source:"DivvyDiary",
      importedAt:new Date().toISOString()
    };
    hist.push(entry);
    existing.add(key);
    added++;
  });
  let report={
    time:new Date().toISOString(),
    portfolioId:portId,
    portfolioName:p(portId).name||portId,
    rowsRead:rows.length,
    added,
    skippedDuplicates:skipped,
    invalid,
    totalHistory:hist.length,
    examples
  };
  db.dividendEngine.lastImport=new Date().toISOString();
  db.dividendEngine.lastImportReport.unshift(report);
  db.dividendEngine.lastImportReport=db.dividendEngine.lastImportReport.slice(0,20);
  return report;
}
function dividendRowsEngineForView(v=view){
  let hist=dividendHistory();
  if(v==="family") return hist;
  return hist.filter(x=>x.portfolioId===v);
}
function dividendAnnualSummary(v=view){
  let rows=dividendRowsEngineForView(v);
  let out={};
  rows.forEach(r=>{
    let y=String(r.payDate||r.exDate||"").slice(0,4)||"Unknown";
    out[y]=out[y]||{year:y,gross:0,net:0,tax:0,count:0};
    out[y].gross+=Number(r.totalGross||0);
    out[y].net+=Number(r.totalNet||0);
    out[y].tax+=Number(r.totalGross||0)-Number(r.totalNet||0);
    out[y].count++;
  });
  return Object.values(out).sort((a,b)=>String(b.year).localeCompare(String(a.year)));
}
function dividendMonthlySummary(v=view){
  let rows=dividendRowsEngineForView(v);
  let out={};
  rows.forEach(r=>{
    let ym=String(r.payDate||r.exDate||"").slice(0,7)||"Unknown";
    out[ym]=out[ym]||{month:ym,gross:0,net:0,tax:0,count:0};
    out[ym].gross+=Number(r.totalGross||0);
    out[ym].net+=Number(r.totalNet||0);
    out[ym].tax+=Number(r.totalGross||0)-Number(r.totalNet||0);
    out[ym].count++;
  });
  return Object.values(out).sort((a,b)=>String(b.month).localeCompare(String(a.month)));
}
function dividendValidationChecks(){
  let checks=[];
  let rows=dividendHistory();
  function add(level,title,msg){checks.push({level,title,msg});}
  let dup=rows.length-new Set(rows.map(x=>x.key)).size;
  if(dup===0) add("ok","Duplicate Dividend Check","Dublikatų nėra.");
  else add("bad","Duplicate Dividend Check","Rasta dublikatų: "+dup);
  let grossNet=rows.filter(r=>Number(r.totalGross||0)+0.0001<Number(r.totalNet||0));
  if(grossNet.length===0) add("ok","Gross / Net Check","Gross nėra mažesnis už Net.");
  else add("bad","Gross / Net Check",grossNet.length+" įrašų, kur Net > Gross.");
  let missingCurrency=rows.filter(r=>!r.currency);
  if(missingCurrency.length===0) add("ok","Currency Check","Visi dividendai turi valiutą.");
  else add("warn","Currency Check",missingCurrency.length+" įrašų be valiutos.");
  let badDates=rows.filter(r=>r.exDate&&r.payDate&&String(r.payDate)<String(r.exDate));
  if(badDates.length===0) add("ok","Date Check","Pay Date nėra ankstesnė už Ex Date.");
  else add("warn","Date Check",badDates.length+" įrašų su Pay Date < Ex Date.");
  let badPortfolio=rows.filter(r=>!p(r.portfolioId).name);
  if(badPortfolio.length===0) add("ok","Portfolio Check","Visi dividendai priskirti portfeliui.");
  else add("bad","Portfolio Check",badPortfolio.length+" dividendų be portfelio.");
  let marius=rows.filter(r=>r.portfolioId==="PORT_MARIUS").length;
  let wife=rows.filter(r=>r.portfolioId==="PORT_WIFE").length;
  add("ok","Portfolio Split",`Marius dividendų eilučių: ${marius}, Žmona: ${wife}, Šeima: ${rows.length}.`);
  return checks;
}



function dividendByTicker(v=view){
  let rows=dividendRowsEngineForView(v);
  let out={};
  rows.forEach(r=>{
    let t=r.ticker||"Unknown";
    out[t]=out[t]||{ticker:t,gross:0,net:0,tax:0,count:0};
    out[t].gross+=Number(r.totalGross||0);
    out[t].net+=Number(r.totalNet||0);
    out[t].tax+=Number(r.totalGross||0)-Number(r.totalNet||0);
    out[t].count++;
  });
  return Object.values(out).sort((a,b)=>b.net-a.net);
}
function dividendCalendarRows(v=view){
  let rows=dividendRowsEngineForView(v).slice();
  return rows
    .filter(r=>r.payDate||r.exDate)
    .sort((a,b)=>String(b.payDate||b.exDate).localeCompare(String(a.payDate||a.exDate)));
}
function currentYearDividendRows(v=view){
  let year=new Date().getFullYear().toString();
  return dividendRowsEngineForView(v).filter(r=>String(r.payDate||r.exDate).slice(0,4)===year);
}
function dividendTopMetrics(v=view){
  let rows=dividendRowsEngineForView(v);
  let gross=rows.reduce((s,r)=>s+Number(r.totalGross||0),0);
  let net=rows.reduce((s,r)=>s+Number(r.totalNet||0),0);
  let tax=gross-net;
  let annual=dividendAnnualSummary(v);
  let monthly=dividendMonthlySummary(v);
  return {rows,gross,net,tax,annual,monthly,avgMonthly: monthly.length?net/monthly.length:0};
}



function dividendStats(v=view){
  let rows=dividendRowsEngineForView(v);
  let tickers=[...new Set(rows.map(r=>r.ticker).filter(Boolean))];
  let years=[...new Set(rows.map(r=>String(r.payDate||r.exDate||"").slice(0,4)).filter(Boolean))];
  let months=[...new Set(rows.map(r=>String(r.payDate||r.exDate||"").slice(0,7)).filter(Boolean))];
  let gross=rows.reduce((s,r)=>s+Number(r.totalGross||0),0);
  let net=rows.reduce((s,r)=>s+Number(r.totalNet||0),0);
  return {rows:rows.length,tickers:tickers.length,years:years.length,months:months.length,gross,net,tax:gross-net};
}
function dividendStableStatus(){
  let checks=dividendValidationChecks();
  let bad=checks.filter(c=>c.level==="bad").length;
  let warn=checks.filter(c=>c.level==="warn").length;
  return bad ? "ERROR" : warn ? "WARNING" : "STABLE";
}


function DividendEngine(){
  let metrics=dividendTopMetrics();
  let rows=metrics.rows;
  let stats=dividendStats();
  let annual=metrics.annual;
  let monthly=metrics.monthly;
  let byTicker=dividendByTicker();
  let calendar=dividendCalendarRows();
  let checks=dividendValidationChecks();
  let status=dividendStableStatus();
  let reports=(db.dividendEngine&&db.dividendEngine.lastImportReport)||[];
  return `<section class="hero card"><div><span class="pill">MIT 2.0.2 FIX2</span><h2>Dividend Engine Stable Candidate</h2><p>Užbaigtas dividendų branduolys: History → Annual → Monthly → Calendar → Ticker summary → Validation.</p></div><div><strong style="font-size:42px">${status}</strong><br><span class="muted">Dividend status</span></div></section>

  <section class="grid"><div class="card"><h3>Import Dividend History</h3><p>Importuok tik DivvyDiary Dividend History CSV. Tas pats failas antrą kartą neprideda dublikatų.</p><label class="upload">Import Marius Dividends<input type="file" accept=".csv" onchange="handleDividendFile(event,'PORT_MARIUS')"></label> <label class="upload">Import Žmona Dividends<input type="file" accept=".csv" onchange="handleDividendFile(event,'PORT_WIFE')"></label></div><div class="card"><h3>Current View</h3><div class="alert ok"><strong>${view==="family"?"Šeima":p(view).name}</strong><br>Viršuje dešinėje gali perjungti Marius / Žmona / Šeima.</div></div></section>

  <section class="metrics"><div class="metric"><span>Dividend rows</span><strong>${stats.rows}</strong></div><div class="metric"><span>Tickers</span><strong>${stats.tickers}</strong></div><div class="metric"><span>Years</span><strong>${stats.years}</strong></div><div class="metric"><span>Active months</span><strong>${stats.months}</strong></div></section>
  <section class="metrics"><div class="metric"><span>Gross</span><strong>${euro(stats.gross)}</strong></div><div class="metric"><span>Net</span><strong>${euro(stats.net)}</strong></div><div class="metric"><span>Tax</span><strong>${euro(stats.tax)}</strong></div><div class="metric"><span>Avg / active month</span><strong>${euro(metrics.avgMonthly)}</strong></div></section>

  <section class="grid"><div class="card"><h3>Annual Summary</h3><table><thead><tr><th>Year</th><th>Gross</th><th>Net</th><th>Tax</th><th>Rows</th></tr></thead><tbody>${annual.map(x=>`<tr><td><strong>${x.year}</strong></td><td>${euro(x.gross)}</td><td>${euro(x.net)}</td><td>${euro(x.tax)}</td><td>${x.count}</td></tr>`).join("")}</tbody></table></div>
  <div class="card"><h3>Monthly Summary</h3><table><thead><tr><th>Month</th><th>Gross</th><th>Net</th><th>Tax</th><th>Rows</th></tr></thead><tbody>${monthly.slice(0,24).map(x=>`<tr><td><strong>${x.month}</strong></td><td>${euro(x.gross)}</td><td>${euro(x.net)}</td><td>${euro(x.tax)}</td><td>${x.count}</td></tr>`).join("")}</tbody></table></div></section>

  <section class="grid"><div class="card"><h3>Dividend by Ticker</h3><table><thead><tr><th>Ticker</th><th>Net</th><th>Gross</th><th>Tax</th><th>Rows</th></tr></thead><tbody>${byTicker.slice(0,50).map(x=>`<tr><td><strong>${x.ticker}</strong></td><td>${euro(x.net)}</td><td>${euro(x.gross)}</td><td>${euro(x.tax)}</td><td>${x.count}</td></tr>`).join("")}</tbody></table></div>
  <div class="card"><h3>Dividend Calendar</h3><table><thead><tr><th>Pay Date</th><th>Ticker</th><th>Portfolio</th><th>Net</th><th>Gross</th></tr></thead><tbody>${calendar.slice(0,80).map(r=>`<tr><td><strong>${r.payDate||r.exDate}</strong></td><td>${r.ticker}</td><td>${p(r.portfolioId).name||""}</td><td>${euro(r.totalNet)}</td><td>${euro(r.totalGross)}</td></tr>`).join("")}</tbody></table></div></section>

  <section class="card"><h3>Last Import Reports</h3>${reports.length?`<table><thead><tr><th>Time</th><th>Portfolio</th><th>Rows</th><th>Added</th><th>Skipped</th><th>Invalid</th><th>Total History</th></tr></thead><tbody>${reports.map(r=>`<tr><td>${String(r.time).slice(0,19).replace("T"," ")}</td><td>${r.portfolioName}</td><td>${r.rowsRead}</td><td>${r.added}</td><td>${r.skippedDuplicates}</td><td>${r.invalid}</td><td>${r.totalHistory}</td></tr>`).join("")}</tbody></table>`:`<div class="empty">Importo ataskaitų dar nėra.</div>`}</section>

  <section class="card"><h3>Dividend Validation</h3>${checks.map(c=>`<div class="alert ${c.level==="ok"?"ok":c.level==="warn"?"warn":"bad"}"><strong>${c.title}</strong><br>${c.msg}</div>`).join("")}</section>

  <section class="card"><h3>Stable Notes</h3><div class="alert ok">Dividend Engine šioje versijoje laikomas Stable Candidate. Forecast ir Dividend Score sąmoningai atidėti vėlesniems etapams.</div></section>`;
}

function handleDividendFile(event,portId){
  let file=event.target.files[0];
  if(!file)return;
  let reader=new FileReader();
  reader.onload=e=>{
    let rows=parseCsv(e.target.result);
    let keys=Object.keys(rows[0]||{});
    if(!(keys.includes("symbol")&&keys.includes("exDate")&&keys.includes("payDate")&&keys.includes("totalNet"))){
      alert("Tai nepanašu į Dividend History CSV. Reikia symbol, exDate, payDate, totalNet laukų.");
      return;
    }
    let report=importDividendHistoryCore(rows,portId);
    alert(`${report.portfolioName}: nuskaityta ${report.rowsRead}, pridėta ${report.added}, praleista dublikatų ${report.skippedDuplicates}, blogų eilučių ${report.invalid}.`);
    save();
  };
  reader.readAsText(file);
}



function transactionsHistory(){
  db.transactionsEngine=db.transactionsEngine||{history:[],settings:{},lastImport:null,lastImportReport:[]};
  db.transactionsEngine.history=db.transactionsEngine.history||[];
  db.transactionsEngine.lastImportReport=db.transactionsEngine.lastImportReport||[];
  return db.transactionsEngine.history;
}
function normalizeTransactionType(v){
  let t=String(v||"").trim().toUpperCase();
  if(t.includes("BUY")||t==="PIRKIMAS") return "BUY";
  if(t.includes("SELL")||t==="PARDAVIMAS") return "SELL";
  if(t.includes("DIV")) return "DIVIDEND";
  if(t.includes("FEE")) return "FEE";
  return t||"UNKNOWN";
}
function transactionKey(portfolioId,row){
  let dt=String(row.datetime||row.date||row.time||"").trim();
  let isin=String(row.isin||"").trim().toUpperCase();
  let symbol=canonicalTicker(row.symbol||row.ticker||"");
  let type=normalizeTransactionType(row.type);
  let qty=parseNumber(row.quantity).toFixed(8);
  let amount=parseNumber(row.amount||row.value||row.total).toFixed(6);
  return [portfolioId,dt,isin||symbol,type,qty,amount].join("|");
}
function importTransactionsCore(rows,portId){
  let hist=transactionsHistory();
  let existing=new Set(hist.map(x=>x.key));
  let added=0, skipped=0, invalid=0;
  rows.forEach((r,idx)=>{
    let symbol=canonicalTicker(r.symbol||r.ticker||"");
    let hasRequired=(r.datetime||r.date||r.time) && (r.isin||symbol) && r.type;
    if(!hasRequired){invalid++;return;}
    let key=transactionKey(portId,r);
    if(existing.has(key)){skipped++;return;}
    let entry={
      id:"TRX_"+String(hist.length+1).padStart(6,"0"),
      key,
      portfolioId:portId,
      datetime:String(r.datetime||r.date||r.time||"").trim(),
      type:normalizeTransactionType(r.type),
      isin:r.isin||"",
      ticker:symbol,
      name:r.name||"",
      quantity:parseNumber(r.quantity),
      price:parseNumber(r.price),
      amount:parseNumber(r.amount||r.value||r.total),
      fees:parseNumber(r.fees||r.fee),
      taxes:parseNumber(r.taxes||r.tax),
      currency:r.currency||"",
      source:"DivvyDiary",
      importedAt:new Date().toISOString()
    };
    hist.push(entry); existing.add(key); added++;
  });
  let report={
    time:new Date().toISOString(),
    portfolioId:portId,
    portfolioName:p(portId).name||portId,
    rowsRead:rows.length,
    added,
    skippedDuplicates:skipped,
    invalid,
    totalHistory:hist.length
  };
  db.transactionsEngine.lastImport=new Date().toISOString();
  db.transactionsEngine.lastImportReport.unshift(report);
  db.transactionsEngine.lastImportReport=db.transactionsEngine.lastImportReport.slice(0,20);
  return report;
}
function transactionRowsForView(v=view){
  let rows=transactionsHistory();
  if(v==="family") return rows;
  return rows.filter(x=>x.portfolioId===v);
}
function transactionSummary(v=view){
  let rows=transactionRowsForView(v);
  let buys=rows.filter(x=>x.type==="BUY");
  let sells=rows.filter(x=>x.type==="SELL");
  let totalBuy=buys.reduce((s,x)=>s+Math.abs(Number(x.amount||0)),0);
  let totalSell=sells.reduce((s,x)=>s+Math.abs(Number(x.amount||0)),0);
  let fees=rows.reduce((s,x)=>s+Math.abs(Number(x.fees||0)),0);
  let taxes=rows.reduce((s,x)=>s+Math.abs(Number(x.taxes||0)),0);
  let tickers=[...new Set(rows.map(x=>x.ticker).filter(Boolean))];
  return {rows:rows.length,buys:buys.length,sells:sells.length,totalBuy,totalSell,fees,taxes,tickers:tickers.length};
}
function transactionsByMonth(v=view){
  let out={};
  transactionRowsForView(v).forEach(x=>{
    let ym=String(x.datetime||"").slice(0,7)||"Unknown";
    out[ym]=out[ym]||{month:ym,buy:0,sell:0,fees:0,count:0};
    if(x.type==="BUY") out[ym].buy+=Math.abs(Number(x.amount||0));
    if(x.type==="SELL") out[ym].sell+=Math.abs(Number(x.amount||0));
    out[ym].fees+=Math.abs(Number(x.fees||0));
    out[ym].count++;
  });
  return Object.values(out).sort((a,b)=>String(b.month).localeCompare(String(a.month)));
}
function transactionsByTicker(v=view){
  let out={};
  transactionRowsForView(v).forEach(x=>{
    let t=x.ticker||"Unknown";
    out[t]=out[t]||{ticker:t,buy:0,sell:0,fees:0,count:0,quantity:0};
    if(x.type==="BUY"){out[t].buy+=Math.abs(Number(x.amount||0));out[t].quantity+=Number(x.quantity||0);}
    if(x.type==="SELL"){out[t].sell+=Math.abs(Number(x.amount||0));out[t].quantity-=Number(x.quantity||0);}
    out[t].fees+=Math.abs(Number(x.fees||0));
    out[t].count++;
  });
  return Object.values(out).sort((a,b)=>(b.buy+b.sell)-(a.buy+a.sell));
}
function transactionValidationChecks(){
  let checks=[], rows=transactionsHistory();
  function add(level,title,msg){checks.push({level,title,msg});}
  let dup=rows.length-new Set(rows.map(x=>x.key)).size;
  if(dup===0)add("ok","Duplicate Transaction Check","Dublikatų nėra.");else add("bad","Duplicate Transaction Check","Rasta dublikatų: "+dup);
  let badPortfolio=rows.filter(r=>!p(r.portfolioId).name);
  if(badPortfolio.length===0)add("ok","Portfolio Check","Visi sandoriai priskirti portfeliui.");else add("bad","Portfolio Check",badPortfolio.length+" sandorių be portfelio.");
  let missingTicker=rows.filter(r=>!r.ticker&&!r.isin);
  if(missingTicker.length===0)add("ok","Ticker / ISIN Check","Visi sandoriai turi ticker arba ISIN.");else add("warn","Ticker / ISIN Check",missingTicker.length+" sandorių be ticker/ISIN.");
  let missingDate=rows.filter(r=>!r.datetime);
  if(missingDate.length===0)add("ok","Date Check","Visi sandoriai turi datą.");else add("bad","Date Check",missingDate.length+" sandorių be datos.");
  let splitM=rows.filter(r=>r.portfolioId==="PORT_MARIUS").length;
  let splitW=rows.filter(r=>r.portfolioId==="PORT_WIFE").length;
  add("ok","Portfolio Split",`Marius: ${splitM}, Žmona: ${splitW}, Šeima: ${rows.length}.`);
  return checks;
}
function TransactionsEngine(){
  let summary=transactionSummary();
  let rows=transactionRowsForView();
  let monthly=transactionsByMonth();
  let byTicker=transactionsByTicker();
  let reports=(db.transactionsEngine&&db.transactionsEngine.lastImportReport)||[];
  let checks=transactionValidationChecks();
  let bad=checks.filter(c=>c.level==="bad").length;
  let warn=checks.filter(c=>c.level==="warn").length;
  return `<section class="hero card"><div><span class="pill">MIT 2.0.2 FIX2</span><h2>Transactions Engine Core</h2><p>DivvyDiary Transactions CSV importas, sandorių istorija, mėnesinė ir tickerių suvestinė.</p></div><div><strong style="font-size:42px">${bad?"ERROR":warn?"WARN":"OK"}</strong><br><span class="muted">Transactions status</span></div></section>

  <section class="grid"><div class="card"><h3>Import Transactions CSV</h3><p>Importuok DivvyDiary Transactions CSV. Tas pats failas antrą kartą neprideda dublikatų.</p><label class="upload">Import Marius Transactions<input type="file" accept=".csv" onchange="handleTransactionFile(event,'PORT_MARIUS')"></label> <label class="upload">Import Žmona Transactions<input type="file" accept=".csv" onchange="handleTransactionFile(event,'PORT_WIFE')"></label></div><div class="card"><h3>Current View</h3><div class="alert ok"><strong>${view==="family"?"Šeima":p(view).name}</strong><br>Viršuje dešinėje gali perjungti Marius / Žmona / Šeima.</div></div></section>

  <section class="metrics"><div class="metric"><span>Transactions</span><strong>${summary.rows}</strong></div><div class="metric"><span>BUY count</span><strong>${summary.buys}</strong></div><div class="metric"><span>SELL count</span><strong>${summary.sells}</strong></div><div class="metric"><span>Tickers</span><strong>${summary.tickers}</strong></div></section>
  <section class="metrics"><div class="metric"><span>Total BUY</span><strong>${euro(summary.totalBuy)}</strong></div><div class="metric"><span>Total SELL</span><strong>${euro(summary.totalSell)}</strong></div><div class="metric"><span>Fees</span><strong>${euro(summary.fees)}</strong></div><div class="metric"><span>Taxes</span><strong>${euro(summary.taxes)}</strong></div></section>

  <section class="grid"><div class="card"><h3>Monthly Transactions</h3><table><thead><tr><th>Month</th><th>BUY</th><th>SELL</th><th>Fees</th><th>Rows</th></tr></thead><tbody>${monthly.slice(0,24).map(x=>`<tr><td><strong>${x.month}</strong></td><td>${euro(x.buy)}</td><td>${euro(x.sell)}</td><td>${euro(x.fees)}</td><td>${x.count}</td></tr>`).join("")}</tbody></table></div>
  <div class="card"><h3>Transactions by Ticker</h3><table><thead><tr><th>Ticker</th><th>BUY</th><th>SELL</th><th>Fees</th><th>Qty Net</th><th>Rows</th></tr></thead><tbody>${byTicker.slice(0,50).map(x=>`<tr><td><strong>${x.ticker}</strong></td><td>${euro(x.buy)}</td><td>${euro(x.sell)}</td><td>${euro(x.fees)}</td><td>${Number(x.quantity||0).toFixed(4)}</td><td>${x.count}</td></tr>`).join("")}</tbody></table></div></section>

  <section class="card"><h3>Last Import Reports</h3>${reports.length?`<table><thead><tr><th>Time</th><th>Portfolio</th><th>Rows</th><th>Added</th><th>Skipped</th><th>Invalid</th><th>Total History</th></tr></thead><tbody>${reports.map(r=>`<tr><td>${String(r.time).slice(0,19).replace("T"," ")}</td><td>${r.portfolioName}</td><td>${r.rowsRead}</td><td>${r.added}</td><td>${r.skippedDuplicates}</td><td>${r.invalid}</td><td>${r.totalHistory}</td></tr>`).join("")}</tbody></table>`:`<div class="empty">Importo ataskaitų dar nėra.</div>`}</section>

  <section class="card"><h3>Transaction Validation</h3>${checks.map(c=>`<div class="alert ${c.level==="ok"?"ok":c.level==="warn"?"warn":"bad"}"><strong>${c.title}</strong><br>${c.msg}</div>`).join("")}</section>

  <section class="card"><h3>Latest Transactions</h3><table><thead><tr><th>Date</th><th>Portfolio</th><th>Type</th><th>Ticker</th><th>Qty</th><th>Price</th><th>Amount</th><th>Fees</th></tr></thead><tbody>${rows.slice().sort((a,b)=>String(b.datetime).localeCompare(String(a.datetime))).slice(0,150).map(r=>`<tr><td>${r.datetime}</td><td>${p(r.portfolioId).name||""}</td><td>${r.type}</td><td>${r.ticker}</td><td>${Number(r.quantity||0).toFixed(4)}</td><td>${euro(r.price)}</td><td>${euro(r.amount)}</td><td>${euro(r.fees)}</td></tr>`).join("")}</tbody></table></section>`;
}
function handleTransactionFile(event,portId){
  let file=event.target.files[0];
  if(!file)return;
  let reader=new FileReader();
  reader.onload=e=>{
    let rows=parseCsv(e.target.result);
    let keys=Object.keys(rows[0]||{});
    if(!(keys.includes("type") && (keys.includes("datetime")||keys.includes("date")) && (keys.includes("symbol")||keys.includes("isin")))){
      alert("Tai nepanašu į Transactions CSV. Reikia type, datetime/date ir symbol/isin laukų.");
      return;
    }
    let report=importTransactionsCore(rows,portId);
    alert(`${report.portfolioName}: nuskaityta ${report.rowsRead}, pridėta ${report.added}, praleista dublikatų ${report.skippedDuplicates}, blogų eilučių ${report.invalid}.`);
    save();
  };
  reader.readAsText(file);
}


function watchlistItems(){
  db.watchlistEngine=db.watchlistEngine||{items:[],settings:{statuses:["BUY","WATCH","EXPENSIVE","HOLD","RESEARCH"],priorities:["A","B","C"]}};
  db.watchlistEngine.items=db.watchlistEngine.items||[];
  return db.watchlistEngine.items;
}
function watchlistId(){
  let arr=watchlistItems();
  let m=0;
  arr.forEach(x=>{
    let n=Number(String(x.id||"").replace("WL_",""));
    if(!isNaN(n))m=Math.max(m,n);
  });
  return "WL_"+String(m+1).padStart(4,"0");
}
function watchStatus(item){
  let target=Number(item.targetPrice||0), current=Number(item.currentPrice||0);
  if(!current || !target) return item.status||"RESEARCH";
  let diff=(current-target)/target*100;
  if(diff<=0) return "BUY";
  if(diff<=10) return "WATCH";
  return "EXPENSIVE";
}
function watchDiff(item){
  let target=Number(item.targetPrice||0), current=Number(item.currentPrice||0);
  if(!current||!target)return null;
  return (current-target)/target*100;
}
function watchScore(item){
  let score=50;
  let st=watchStatus(item);
  if(item.priority==="A")score+=25;
  if(item.priority==="B")score+=12;
  if(item.priority==="C")score+=3;
  if(st==="BUY")score+=25;
  if(st==="WATCH")score+=12;
  if(st==="EXPENSIVE")score-=15;
  if(item.risk==="High")score-=8;
  if(item.risk==="Low")score+=5;
  return Math.max(0,Math.min(100,score));
}
function statusBadge(status){
  let cls=status==="BUY"?"ok":status==="WATCH"?"warn":status==="EXPENSIVE"?"bad":"info";
  return `<span class="badge ${cls}">${status}</span>`;
}
function addWatchItem(){
  let ticker=prompt("Ticker, pvz. VICI, ZTS, ANAV:");
  if(!ticker)return;
  let name=prompt("Pavadinimas:", ticker) || ticker;
  let type=prompt("Tipas: stock / etf / risk_stock / reit / crypto", "stock") || "stock";
  let target=Number(prompt("Norima pirkimo kaina (gali būti 0):", "0")||0);
  let current=Number(prompt("Dabartinė kaina rankiniu būdu (gali būti 0):", "0")||0);
  let priority=prompt("Prioritetas A/B/C:", "B") || "B";
  let risk=prompt("Rizika Low/Medium/High:", "Medium") || "Medium";
  let note=prompt("Komentaras:", "") || "";
  watchlistItems().push({id:watchlistId(),ticker:canonicalTicker(ticker),name,type,sector:"",targetPrice:target,currentPrice:current,currency:"USD",priority:priority.toUpperCase(),risk,status:"RESEARCH",note,createdAt:new Date().toISOString().slice(0,10)});
  save();
}
function editWatchItem(id){
  let item=watchlistItems().find(x=>x.id===id);
  if(!item)return;
  item.targetPrice=Number(prompt("Norima pirkimo kaina:", item.targetPrice||0)||0);
  item.currentPrice=Number(prompt("Dabartinė kaina:", item.currentPrice||0)||0);
  item.priority=(prompt("Prioritetas A/B/C:", item.priority||"B")||"B").toUpperCase();
  item.risk=prompt("Rizika Low/Medium/High:", item.risk||"Medium")||"Medium";
  item.note=prompt("Komentaras:", item.note||"")||"";
  item.status=watchStatus(item);
  save();
}
function deleteWatchItem(id){
  if(!confirm("Ištrinti iš watchlist?"))return;
  db.watchlistEngine.items=watchlistItems().filter(x=>x.id!==id);
  save();
}
function watchlistSummary(){
  let items=watchlistItems();
  let buy=items.filter(x=>watchStatus(x)==="BUY").length;
  let watch=items.filter(x=>watchStatus(x)==="WATCH").length;
  let expensive=items.filter(x=>watchStatus(x)==="EXPENSIVE").length;
  let research=items.filter(x=>["RESEARCH","HOLD"].includes(watchStatus(x))).length;
  return {items:items.length,buy,watch,expensive,research};
}
function Watchlist(){
  let s=watchlistSummary();
  let items=watchlistItems().slice().sort((a,b)=>watchScore(b)-watchScore(a));
  return `<section class="hero card"><div><span class="pill">MIT 2.0.2 FIX2</span><h2>Watchlist Core</h2><p>Pirmas investavimo sprendimų modulis: norima kaina, dabartinė kaina, prioritetas, statusas ir komentarai.</p></div><div><strong style="font-size:42px">${s.items}</strong><br><span class="muted">Watch items</span></div></section>
  <section class="metrics"><div class="metric"><span>BUY</span><strong>${s.buy}</strong></div><div class="metric"><span>WATCH</span><strong>${s.watch}</strong></div><div class="metric"><span>EXPENSIVE</span><strong>${s.expensive}</strong></div><div class="metric"><span>Research / Hold</span><strong>${s.research}</strong></div></section>
  <section class="card"><div class="section"><h3>Watchlist</h3><button class="btn green" onclick="addWatchItem()">+ Add Watch Item</button></div>
  <table><thead><tr><th>Ticker</th><th>Name</th><th>Type</th><th>Target</th><th>Current</th><th>Diff</th><th>Status</th><th>Priority</th><th>Risk</th><th>Score</th><th>Note</th><th>Actions</th></tr></thead><tbody>${items.map(x=>{
    let diff=watchDiff(x);
    let st=watchStatus(x);
    return `<tr><td><strong>${x.ticker}</strong></td><td>${x.name||""}</td><td>${x.type||""}</td><td>${x.targetPrice?Number(x.targetPrice).toFixed(2)+" "+(x.currency||""):"-"}</td><td>${x.currentPrice?Number(x.currentPrice).toFixed(2)+" "+(x.currency||""):"-"}</td><td>${diff===null?"-":diff.toFixed(1)+"%"}</td><td>${statusBadge(st)}</td><td>${x.priority||""}</td><td>${x.risk||""}</td><td><strong>${watchScore(x)}</strong></td><td>${x.note||""}</td><td><button class="btn secondary" onclick="editWatchItem('${x.id}')">Edit</button> <button class="btn red" onclick="deleteWatchItem('${x.id}')">Delete</button></td></tr>`;
  }).join("")}</tbody></table></section>
  <section class="card"><h3>Watchlist taisyklė</h3><div class="alert ok">BUY = dabartinė kaina lygi arba mažesnė už tavo norimą kainą. WATCH = iki 10% virš tavo kainos. EXPENSIVE = daugiau nei 10% virš tavo kainos.</div></section>`;
}


function universe(){
  db.universeEngine=db.universeEngine||{stockUniverse:[],etfUniverse:[],highRiskUniverse:[],scoreWeights:{}};
  db.universeEngine.stockUniverse=db.universeEngine.stockUniverse||[];
  db.universeEngine.etfUniverse=db.universeEngine.etfUniverse||[];
  db.universeEngine.highRiskUniverse=db.universeEngine.highRiskUniverse||[];
  return db.universeEngine;
}
function avg(vals){let nums=vals.map(Number).filter(x=>!isNaN(x));return nums.length?nums.reduce((a,b)=>a+b,0)/nums.length:0}
function scoreFromFive(x){return Math.max(0,Math.min(100,Number(x||0)*20))}
function stockMoatScore(s){let m=s.moat||{};return Math.round(avg([m.brand,m.switchingCosts,m.networkEffect,m.costAdvantage,m.scale,m.patents,m.regulatory].map(scoreFromFive)))}
function stockResearchPercent(s){let r=s.research||{};let keys=Object.keys(r);return keys.length?Math.round(keys.filter(k=>r[k]).length/keys.length*100):0}
function stockMitScore(s){let scores=s.scores||{};return Math.round(avg([Number(scores.moat||stockMoatScore(s)),Number(scores.financial||0),Number(scores.valuation||0),Number(scores.portfolioFit||0),Number(scores.opportunity||0)]))}
function universeSummary(){let u=universe();return {stocks:u.stockUniverse.length,etfs:u.etfUniverse.length,risk:u.highRiskUniverse.length,ownedStocks:u.stockUniverse.filter(x=>x.status==="Owned").length,candidates:u.stockUniverse.filter(x=>x.status==="Candidate").length,total:u.stockUniverse.length+u.etfUniverse.length+u.highRiskUniverse.length}}
function addStockUniverse(){
  let ticker=prompt("Ticker:"); if(!ticker)return;
  universe().stockUniverse.push({id:"STK_"+String(universe().stockUniverse.length+1).padStart(4,"0"),ticker:canonicalTicker(ticker),name:prompt("Company:",ticker)||ticker,status:prompt("Status Owned/Candidate/Archived:","Candidate")||"Candidate",type:"stock",sector:prompt("Sector:","")||"",industry:"",country:prompt("Country:","US")||"US",currency:prompt("Currency:","USD")||"USD",broker:"",portfolio:{owned:false,positionValue:0,positionWeight:0,targetMin:1,targetMax:3,maxWeight:5,stage:"NEW"},research:{msnMoney:false,morningstar:false,guruFocus:false,finviz:false,trefis:false,divvyDiary:false,annualReport:false,earnings:false},moat:{brand:0,switchingCosts:0,networkEffect:0,costAdvantage:0,scale:0,patents:0,regulatory:0,score:0},financials:{score:0},valuation:{score:0},opportunity:{targetPrice:0,currentPrice:0,score:0},scores:{quality:0,moat:0,financial:0,valuation:0,portfolioFit:0,opportunity:0,mit:0},action:"WATCH",conviction:0,thesis:"",risks:"",notes:""});
  save();
}
function editStockUniverse(id){
  let s=universe().stockUniverse.find(x=>x.id===id); if(!s)return;
  s.status=prompt("Status Owned/Candidate/Archived:",s.status||"Candidate")||s.status;
  s.portfolio.targetMin=Number(prompt("Target min %:",s.portfolio?.targetMin||1)||s.portfolio.targetMin||1);
  s.portfolio.targetMax=Number(prompt("Target max %:",s.portfolio?.targetMax||3)||s.portfolio.targetMax||3);
  s.action=prompt("Action OPEN/ADD/HOLD/WATCH/WAIT/REDUCE:",s.action||"WATCH")||s.action;
  s.conviction=Number(prompt("Conviction 0-10:",s.conviction||0)||0);
  s.thesis=prompt("Investment thesis:",s.thesis||"")||s.thesis||"";
  s.notes=prompt("Notes:",s.notes||"")||s.notes||"";
  save();
}
function UniverseDashboard(){
  let s=universeSummary();
  return `<section class="hero card"><div><span class="pill">MIT 2.0 Core</span><h2>Universe Database</h2><p>MIT nuo šiol saugo visą investavimo visatą: akcijas, ETF ir rizikingas idėjas.</p></div><div><strong style="font-size:42px">${s.total}</strong><br><span class="muted">Universe items</span></div></section>
  <section class="metrics"><div class="metric"><span>Stocks</span><strong>${s.stocks}</strong></div><div class="metric"><span>ETF</span><strong>${s.etfs}</strong></div><div class="metric"><span>High Risk</span><strong>${s.risk}</strong></div><div class="metric"><span>Owned Stocks</span><strong>${s.ownedStocks}</strong></div></section>
  <section class="grid"><div class="card"><h3>Architecture</h3><div class="alert ok"><strong>Stock Universe</strong><br>Turimos ir kandidatinės kokybiškos akcijos.</div><div class="alert ok"><strong>ETF Universe</strong><br>Core, dividend, cash, region, sector ETF.</div><div class="alert ok"><strong>High Risk Universe</strong><br>Rizikingos idėjos su griežtais limitais.</div></div>
  <div class="card"><h3>Marius Profile</h3><pre>${JSON.stringify(db.mitProfile?.profiles?.Marius||{},null,2)}</pre></div></section>`;
}
function StockUniverse(){
  let rows=universe().stockUniverse.slice().sort((a,b)=>stockMitScore(b)-stockMitScore(a));
  return `<section class="card"><div class="section"><h3>Stock Universe</h3><button class="btn green" onclick="addStockUniverse()">+ Add Stock</button></div>
  <table><thead><tr><th>Ticker</th><th>Name</th><th>Status</th><th>Sector</th><th>Stage</th><th>Target Range</th><th>Moat</th><th>Research</th><th>MIT Score</th><th>Action</th><th>Conviction</th><th>Thesis</th><th>Actions</th></tr></thead><tbody>${rows.map(x=>`<tr><td><button class="btn secondary" onclick="openInvestmentCard('stock','${x.id}')"><strong>${x.ticker}</strong></button></td><td>${x.name||""}</td><td>${x.status||""}</td><td>${x.sector||""}</td><td>${x.portfolio?.stage||""}</td><td>${x.portfolio?.targetMin||0}-${x.portfolio?.targetMax||0}%</td><td>${stockMoatScore(x)}</td><td>${stockResearchPercent(x)}%</td><td><strong>${stockMitScore(x)}</strong></td><td>${x.action||""}</td><td>${x.conviction||0}/10</td><td>${x.thesis||""}</td><td><button class="btn secondary" onclick="editStockUniverse('${x.id}')">Edit</button></td></tr>`).join("")}</tbody></table></section>`;
}
function ETFUniverse(){
  let rows=universe().etfUniverse||[];
  return `<section class="card"><h3>ETF Universe</h3><table><thead><tr><th>Ticker</th><th>Name</th><th>Status</th><th>Category</th><th>Purpose</th><th>UCITS</th><th>TER</th><th>Region</th><th>Target</th><th>Stage</th><th>Action</th></tr></thead><tbody>${rows.map(x=>`<tr><td><button class="btn secondary" onclick="openInvestmentCard('etf','${x.id}')"><strong>${x.ticker}</strong></button></td><td>${x.name||""}</td><td>${x.status||""}</td><td>${x.category||""}</td><td>${x.purpose||""}</td><td>${x.ucits?"Yes":"No"}</td><td>${x.ter||0}%</td><td>${x.region||""}</td><td>${x.portfolio?.targetWeight||0}%</td><td>${x.portfolio?.stage||""}</td><td>${x.action||""}</td></tr>`).join("")}</tbody></table></section>`;
}
function HighRiskUniverse(){
  let rows=universe().highRiskUniverse||[];
  return `<section class="card"><h3>High Risk Universe</h3><table><thead><tr><th>Ticker</th><th>Name</th><th>Status</th><th>Theme</th><th>Risk</th><th>Target Range</th><th>Max</th><th>Action</th><th>Conviction</th><th>Notes</th></tr></thead><tbody>${rows.map(x=>`<tr><td><button class="btn secondary" onclick="openInvestmentCard('risk','${x.id}')"><strong>${x.ticker}</strong></button></td><td>${x.name||""}</td><td>${x.status||""}</td><td>${x.theme||""}</td><td>${x.risk?.level||""}</td><td>${x.portfolio?.targetMin||0}-${x.portfolio?.targetMax||0}%</td><td>${x.portfolio?.maxWeight||0}%</td><td>${x.action||""}</td><td>${x.conviction||0}/10</td><td>${x.notes||""}</td></tr>`).join("")}</tbody></table></section>`;
}


let activeCardTab="overview";
let activeCardId=null;
let activeCardType=null;


// MIT 2.0.2 FIX2 FIX1 — guaranteed Research helper fallback
function getResearchSources(){return getResearchSourcesSafe()}
function getResearchSourcesSafe(){
  return ["msnMoney","morningstar","guruFocus","finviz","trefis","divvyDiary","annualReport","earnings","investorPresentation"];
}
function ensureResearchObject(item){return ensureResearchObjectSafe(item)}
function richResearchPercent(item){
  item=item||{};
  item.research=item.research||{};
  let keys=getResearchSourcesSafe();
  let done=0;
  keys.forEach(k=>{
    let v=item.research[k];
    if(v===true || (v && typeof v==="object" && v.done)) done++;
  });
  return Math.round(done/keys.length*100);
}
function ensureResearchObjectSafe(item){
  item=item||{};
  item.research=item.research||{};
  getResearchSourcesSafe().forEach(k=>{
    let v=item.research[k];
    if(typeof v==="boolean") item.research[k]={done:v,date:"",notes:""};
    if(!item.research[k]) item.research[k]={done:false,date:"",notes:""};
  });
  item.knowledge=item.knowledge||{business:"",competitiveAdvantages:"",risks:"",catalysts:"",whyOwn:"",whySell:"",lessonsLearned:"",personalNotes:""};
  item.thesisDetails=item.thesisDetails||{whyBuy:item.thesis||"",whyNow:"",advantages:"",risks:item.risks||"",whatWouldChangeMind:""};
  item.researchTimeline=item.researchTimeline||[];
  item.attachments=item.attachments||[];
  if(item.confidence===undefined)item.confidence=item.conviction?item.conviction*10:0;
  if(!item.analysisStatus)item.analysisStatus=item.status==="Candidate"?"New Idea":"In Progress";
  return item;
}

function allUniverseItems(){
  let u=universe();
  return [
    ...(u.stockUniverse||[]).map(x=>({...x,_bucket:"stock"})),
    ...(u.etfUniverse||[]).map(x=>({...x,_bucket:"etf"})),
    ...(u.highRiskUniverse||[]).map(x=>({...x,_bucket:"risk"}))
  ];
}
function findUniverseItem(type,id){
  let u=universe();
  let arr=type==="stock"?u.stockUniverse:type==="etf"?u.etfUniverse:u.highRiskUniverse;
  return (arr||[]).find(x=>x.id===id);
}
function openInvestmentCard(type,id){
  activeCardType=type;
  activeCardId=id;
  activeCardTab="overview";
  setPage("investmentCard");
}
function setCardTab(tab){
  activeCardTab=tab;
  renderPage();
}
function starLine(label,score){
  let n=Math.round(Number(score||0)/20);
  let stars="★★★★★".slice(0,n)+"☆☆☆☆☆".slice(0,5-n);
  return `<div class="bar-label"><span>${label}</span><span>${stars} · ${Number(score||0).toFixed(0)}/100</span></div>`;
}
function cardResearchPercent(item){
  let r=item.research||{};
  let keys=Object.keys(r);
  return keys.length?Math.round(keys.filter(k=>r[k]).length/keys.length*100):0;
}
function cardScore(item){
  if(item.mitScoreEngine){try{return calcMitScore(item).score}catch(e){}} if(item.decisionEngine){try{return calcDecisionScore(item)}catch(e){}} if(item.qualityEngine){try{return calcQualityScore(item).qualityScore}catch(e){}} if(item._bucket==="stock" || item.type==="stock") return stockMitScore(item);
  let sc=item.scores||{};
  return Math.round(avg(Object.values(sc).map(Number)));
}
function cardQuickSummary(item){
  let score=cardScore(item);
  let research=richResearchPercent(item);
  let status=item.analysisStatus||"New Idea";
  let confidence=Number(item.confidence||item.conviction*10||0);
  return `<section class="metrics"><div class="metric"><span>MIT Score</span><strong>${score}</strong></div><div class="metric"><span>Research</span><strong>${research}%</strong></div><div class="metric"><span>Confidence</span><strong>${confidence}%</strong></div><div class="metric"><span>Action</span><strong>${item.action||"WATCH"}</strong></div></section>
  <section class="card"><h3>Decision Summary</h3>
    ${starLine("Quality / MIT",score)}
    ${starLine("Research Complete",research)}
    ${starLine("Confidence",confidence)}
    <div class="alert ok"><strong>Analysis Status:</strong> ${status}<br><strong>Current Action:</strong> ${item.action||"WATCH"}</div>
  </section>`;
}
function cardTabs(){
  let tabs=[["overview","Overview"],["research","Research"],["quality","⭐ Quality"],["decision","🎯 Decision"],["mitScore","⭐ MIT Score"],["financials","Financials"],["valuation","Valuation"],["thesis","Thesis"],["history","History"]];
  return `<div class="tabs">${tabs.map(t=>`<button class="nav ${activeCardTab===t[0]?"active":""}" onclick="setCardTab('${t[0]}')">${t[1]}</button>`).join("")}</div>`;
}
function cardOverview(item,type){
  return `<section class="grid"><div class="card"><h3>Overview</h3><table><tbody>
  <tr><td>Ticker</td><td><strong>${item.ticker}</strong></td></tr>
  <tr><td>Name</td><td>${item.name||""}</td></tr>
  <tr><td>Type</td><td>${type}</td></tr>
  <tr><td>Status</td><td>${item.status||""}</td></tr>
  <tr><td>Sector / Category</td><td>${item.sector||item.category||""}</td></tr>
  <tr><td>Country / Region</td><td>${item.country||item.region||""}</td></tr>
  <tr><td>Currency</td><td>${item.currency||""}</td></tr>
  <tr><td>Broker</td><td>${item.broker||""}</td></tr>
  </tbody></table></div>
  <div class="card"><h3>Portfolio</h3><table><tbody>
  <tr><td>Owned</td><td>${item.portfolio?.owned?"Yes":"No"}</td></tr>
  <tr><td>Position €</td><td>${euro(item.portfolio?.positionValue||0)}</td></tr>
  <tr><td>Position %</td><td>${Number(item.portfolio?.positionWeight||0).toFixed(2)}%</td></tr>
  <tr><td>Target Range / Weight</td><td>${item.portfolio?.targetWeight!==undefined?item.portfolio.targetWeight+"%":(item.portfolio?.targetMin||0)+"-"+(item.portfolio?.targetMax||0)+"%"}</td></tr>
  <tr><td>Max Weight</td><td>${item.portfolio?.maxWeight||"-"}%</td></tr>
  <tr><td>Stage</td><td>${item.portfolio?.stage||""}</td></tr>
  </tbody></table></div></section>`;
}

function cardResearch(item){
  ensureResearchObject(item);
  return `${renderResearchDashboard(item)}${renderResearchChecklist(item)}${renderAttachmentsBase(item)}`;
}

function cardFinancials(item){
  let f=item.financials||{};
  return `<section class="card"><h3>Financial Quality</h3><table><tbody>${["revenueGrowth","epsGrowth","fcf","roe","roic","grossMargin","operatingMargin","netMargin","debtEquity","interestCoverage","score"].map(k=>`<tr><td>${k}</td><td>${f[k]??""}</td></tr>`).join("")}</tbody></table></section>`;
}
function cardValuation(item){
  let v=item.valuation||{};
  let o=item.opportunity||{};
  return `<section class="grid"><div class="card"><h3>Valuation</h3><table><tbody>${["pe","forwardPe","peg","evEbitda","priceFcf","fairValue","marginOfSafety","score"].map(k=>`<tr><td>${k}</td><td>${v[k]??""}</td></tr>`).join("")}</tbody></table></div>
  <div class="card"><h3>Opportunity</h3><table><tbody>${["targetPrice","currentPrice","ath","correction","entryZone","score"].map(k=>`<tr><td>${k}</td><td>${o[k]??""}</td></tr>`).join("")}</tbody></table></div></section>`;
}

function cardThesis(item){
  ensureResearchObject(item);
  return `${renderThesisEditor(item)}${renderKnowledgeEditor(item)}`;
}


function cardHistory(item){
  ensureResearchObject(item);
  return `${renderResearchTimeline(item)}`;
}


// MIT 2.0.2 FIX2 — safe tab renderers
function esc(v){
  return String(v===undefined||v===null?"":v)
    .replace(/&/g,"&amp;")
    .replace(/</g,"&lt;")
    .replace(/>/g,"&gt;")
    .replace(/"/g,"&quot;");
}
function safeItem(item){
  item=item||{};
  if(typeof ensureResearchObjectSafe==="function") ensureResearchObjectSafe(item);
  item.research=item.research||{};
  item.knowledge=item.knowledge||{business:"",competitiveAdvantages:"",risks:"",catalysts:"",whyOwn:"",whySell:"",lessonsLearned:"",personalNotes:""};
  item.thesisDetails=item.thesisDetails||{whyBuy:item.thesis||"",whyNow:"",advantages:"",risks:item.risks||"",whatWouldChangeMind:""};
  item.researchTimeline=item.researchTimeline||[];
  item.attachments=item.attachments||[];
  item.analysisStatus=item.analysisStatus||"New Idea";
  item.confidence=item.confidence||0;
  return item;
}
function safeResearchSources(){
  if(typeof getResearchSourcesSafe==="function") return getResearchSourcesSafe();
  if(typeof getResearchSources==="function") return getResearchSources();
  return ["msnMoney","morningstar","guruFocus","finviz","trefis","divvyDiary","annualReport","earnings","investorPresentation"];
}
function safeSourceLabel(k){
  if(typeof sourceLabel==="function") return sourceLabel(k);
  return k;
}
function safeSourcePurpose(k){
  if(typeof sourcePurpose==="function") return sourcePurpose(k);
  return "";
}
function safeUpdateResearchField(source,field,value){
  let item=findUniverseItem(activeCardType,activeCardId);
  if(!item)return;
  safeItem(item);
  item.research[source]=item.research[source]||{done:false,date:"",notes:""};
  if(field==="done") item.research[source].done=!!value;
  else item.research[source][field]=value;
  item.researchTimeline.unshift({date:new Date().toISOString().slice(0,10),event:"Research updated",note:source+" "+field});
  save();
}
function safeUpdateCardValue(path,value){
  let item=findUniverseItem(activeCardType,activeCardId);
  if(!item)return;
  safeItem(item);
  let parts=path.split(".");
  let obj=item;
  for(let i=0;i<parts.length-1;i++){obj[parts[i]]=obj[parts[i]]||{};obj=obj[parts[i]];}
  obj[parts[parts.length-1]]=value;
  item.researchTimeline.unshift({date:new Date().toISOString().slice(0,10),event:"Card updated",note:path});
  save();
}
function safeReviewStatus(item){
  item=safeItem(item);
  if(!item.nextReview)return "No review date";
  let today=new Date().toISOString().slice(0,10);
  return item.nextReview<today ? "Overdue" : "OK";
}
function renderResearchDashboard(item){
  item=safeItem(item);
  let progress=richResearchPercent(item);
  let status=safeReviewStatus(item);
  return `<section class="metrics"><div class="metric"><span>Analysis Status</span><strong>${esc(item.analysisStatus)}</strong></div><div class="metric"><span>Research Progress</span><strong>${progress}%</strong></div><div class="metric"><span>Confidence</span><strong>${Number(item.confidence||0)}%</strong></div><div class="metric"><span>Review</span><strong>${status}</strong></div></section>
  <section class="card"><h3>Research Dashboard</h3>
  <div class="grid">
    <label>Analysis Status<select class="input" onchange="safeUpdateCardValue('analysisStatus',this.value)"><option ${item.analysisStatus==="New Idea"?"selected":""}>New Idea</option><option ${item.analysisStatus==="In Progress"?"selected":""}>In Progress</option><option ${item.analysisStatus==="Complete"?"selected":""}>Complete</option><option ${item.analysisStatus==="Archived"?"selected":""}>Archived</option></select></label>
    <label>Confidence %<input class="input" type="number" min="0" max="100" value="${Number(item.confidence||0)}" onchange="safeUpdateCardValue('confidence',Number(this.value))"></label>
    <label>Last Review<input class="input" type="date" value="${esc(item.lastReview||"")}" onchange="safeUpdateCardValue('lastReview',this.value)"></label>
    <label>Next Review<input class="input" type="date" value="${esc(item.nextReview||"")}" onchange="safeUpdateCardValue('nextReview',this.value)"></label>
  </div>
  <div class="alert ${status==='Overdue'?'bad':'ok'}"><strong>Research Complete:</strong> ${progress}%<br><strong>Review Status:</strong> ${status}</div></section>`;
}
function renderResearchChecklist(item){
  item=safeItem(item);
  let keys=safeResearchSources();
  return `<section class="card"><h3>Research Checklist</h3><table><thead><tr><th>Source</th><th>Purpose</th><th>Done</th><th>Date</th><th>Notes</th></tr></thead><tbody>${keys.map(k=>{
    let r=item.research[k]||{done:false,date:"",notes:""};
    return `<tr><td><strong>${esc(safeSourceLabel(k))}</strong></td><td>${esc(safeSourcePurpose(k))}</td><td><input type="checkbox" ${r.done?"checked":""} onchange="safeUpdateResearchField('${k}','done',this.checked)"></td><td><input class="input" type="date" value="${esc(r.date||"")}" onchange="safeUpdateResearchField('${k}','date',this.value)"></td><td><input class="input" value="${esc(r.notes||"")}" onchange="safeUpdateResearchField('${k}','notes',this.value)"></td></tr>`;
  }).join("")}</tbody></table></section>`;
}
function renderAttachmentsBase(item){
  item=safeItem(item);
  return `<section class="card"><h3>Attachments</h3><div class="alert warn">Pagrindas paruoštas. Vėliau pridėsime PDF, Excel, screenshot ir notes prisegimą.</div><table><thead><tr><th>Name</th><th>Type</th><th>Note</th></tr></thead><tbody>${(item.attachments||[]).map(a=>`<tr><td>${esc(a.name||"")}</td><td>${esc(a.type||"")}</td><td>${esc(a.note||"")}</td></tr>`).join("")}</tbody></table></section>`;
}
function renderThesisEditor(item){
  item=safeItem(item);
  let t=item.thesisDetails||{};
  return `<section class="card"><h3>Investment Thesis</h3>
  <label>Kodėl perku?<textarea class="input" rows="3" onchange="safeUpdateCardValue('thesisDetails.whyBuy',this.value)">${esc(t.whyBuy||"")}</textarea></label>
  <label>Kodėl dabar?<textarea class="input" rows="3" onchange="safeUpdateCardValue('thesisDetails.whyNow',this.value)">${esc(t.whyNow||"")}</textarea></label>
  <label>Pagrindiniai privalumai<textarea class="input" rows="3" onchange="safeUpdateCardValue('thesisDetails.advantages',this.value)">${esc(t.advantages||"")}</textarea></label>
  <label>Pagrindinės rizikos<textarea class="input" rows="3" onchange="safeUpdateCardValue('thesisDetails.risks',this.value)">${esc(t.risks||"")}</textarea></label>
  <label>Kas pakeistų mano nuomonę?<textarea class="input" rows="3" onchange="safeUpdateCardValue('thesisDetails.whatWouldChangeMind',this.value)">${esc(t.whatWouldChangeMind||"")}</textarea></label>
  </section>`;
}
function renderKnowledgeEditor(item){
  item=safeItem(item);
  let k=item.knowledge||{};
  let fields=[["business","Business"],["competitiveAdvantages","Competitive Advantages"],["risks","Risks"],["catalysts","Catalysts"],["whyOwn","Why I Own It"],["whySell","Why I Would Sell It"],["lessonsLearned","Lessons Learned"],["personalNotes","Personal Notes"]];
  return `<section class="card"><h3>Knowledge Base</h3>${fields.map(f=>`<label>${f[1]}<textarea class="input" rows="3" onchange="safeUpdateCardValue('knowledge.${f[0]}',this.value)">${esc(k[f[0]]||"")}</textarea></label>`).join("")}</section>`;
}
function renderResearchTimeline(item){
  item=safeItem(item);
  let rows=item.researchTimeline||[];
  return `<section class="card"><h3>Research Timeline</h3>${rows.length?`<table><thead><tr><th>Date</th><th>Event</th><th>Note</th></tr></thead><tbody>${rows.map(x=>`<tr><td>${esc(x.date||"")}</td><td>${esc(x.event||"")}</td><td>${esc(x.note||"")}</td></tr>`).join("")}</tbody></table>`:`<div class="empty">Research Timeline dar tuščias.</div>`}</section>`;
}
function cardResearch(item){return `${renderResearchDashboard(item)}${renderResearchChecklist(item)}${renderAttachmentsBase(item)}`}
function cardThesis(item){return `${renderThesisEditor(item)}${renderKnowledgeEditor(item)}`}
function cardHistory(item){return `${renderResearchTimeline(item)}`}


function qAvg(vals){
  let nums=vals.map(Number).filter(x=>!isNaN(x));
  return nums.length?nums.reduce((a,b)=>a+b,0)/nums.length:0;
}
function q5(v){return Math.max(0,Math.min(100,Number(v||0)*20));}
function ensureQualityEngine(item){
  item=item||{};
  item.moat=item.moat||{brand:0,switchingCosts:0,networkEffect:0,costAdvantage:0,scale:0,patents:0,regulatory:0,score:0};
  item.financials=item.financials||{revenueGrowth:0,epsGrowth:0,fcf:0,roe:0,roic:0,grossMargin:0,operatingMargin:0,netMargin:0,debtEquity:0,interestCoverage:0,score:0};
  item.qualityEngine=item.qualityEngine||{};
  item.qualityEngine.weights=item.qualityEngine.weights||{moat:25,financial:25,business:20,management:15,growth:15};
  item.qualityEngine.business=item.qualityEngine.business||{understandableBusiness:0,durableDemand:0,pricingPower:0,businessModel:0,cyclicality:0,score:0,notes:""};
  item.qualityEngine.management=item.qualityEngine.management||{capitalAllocation:0,buybacks:0,dividendPolicy:0,insiderOwnership:0,communication:0,score:0,notes:""};
  item.qualityEngine.growth=item.qualityEngine.growth||{tam:0,innovation:0,expansion:0,newProducts:0,international:0,score:0,notes:""};
  item.qualityEngine.summary=item.qualityEngine.summary||{moatScore:0,financialScore:0,businessScore:0,managementScore:0,growthScore:0,qualityScore:0};
  return item;
}
function calcMoatScore(item){
  item=ensureQualityEngine(item);
  let m=item.moat||{};
  return Math.round(qAvg([m.brand,m.switchingCosts,m.networkEffect,m.costAdvantage,m.scale,m.patents,m.regulatory].map(q5)));
}
function calcFinancialScore(item){
  item=ensureQualityEngine(item);
  let f=item.financials||{};
  let positive=qAvg([f.revenueGrowth,f.epsGrowth,f.fcf,f.roe,f.roic,f.grossMargin,f.operatingMargin,f.netMargin].map(Number));
  let debtPenalty=Math.max(0,Math.min(100,100-Number(f.debtEquity||0)*20));
  let interest=Math.max(0,Math.min(100,Number(f.interestCoverage||0)*10));
  let vals=[positive,debtPenalty,interest].filter(x=>!isNaN(x));
  return Math.round(qAvg(vals));
}
function calcSectionScore(obj,keys){
  return Math.round(qAvg(keys.map(k=>q5(obj[k]))));
}
function calcQualityScore(item){
  item=ensureQualityEngine(item);
  let q=item.qualityEngine;
  let moat=calcMoatScore(item);
  let financial=calcFinancialScore(item);
  let business=calcSectionScore(q.business,["understandableBusiness","durableDemand","pricingPower","businessModel","cyclicality"]);
  let management=calcSectionScore(q.management,["capitalAllocation","buybacks","dividendPolicy","insiderOwnership","communication"]);
  let growth=calcSectionScore(q.growth,["tam","innovation","expansion","newProducts","international"]);
  let w=q.weights||{moat:25,financial:25,business:20,management:15,growth:15};
  let total=(moat*w.moat+financial*w.financial+business*w.business+management*w.management+growth*w.growth)/(w.moat+w.financial+w.business+w.management+w.growth);
  q.summary={moatScore:moat,financialScore:financial,businessScore:business,managementScore:management,growthScore:growth,qualityScore:Math.round(total)};
  item.scores=item.scores||{};
  item.scores.quality=q.summary.qualityScore;
  item.scores.moat=moat;
  item.scores.financial=financial;
  return q.summary;
}
function qStars(score){
  let n=Math.round(Number(score||0)/20);
  return "★★★★★".slice(0,n)+"☆☆☆☆☆".slice(0,5-n);
}
function updateQualityField(section,key,value){
  let item=findUniverseItem(activeCardType,activeCardId);
  if(!item)return;
  ensureQualityEngine(item);
  if(section==="moat") item.moat[key]=Number(value);
  else if(section==="financials") item.financials[key]=Number(value);
  else item.qualityEngine[section][key]=Number(value);
  calcQualityScore(item);
  if(typeof addTimeline==="function") addTimeline(item,"Quality updated",section+"."+key);
  save();
}
function updateQualityNote(section,value){
  let item=findUniverseItem(activeCardType,activeCardId);
  if(!item)return;
  ensureQualityEngine(item);
  item.qualityEngine[section].notes=value;
  if(typeof addTimeline==="function") addTimeline(item,"Quality note updated",section);
  save();
}
function qSlider(section,key,label,value){
  return `<label>${label}: <strong>${value||0}/5</strong><input class="input" type="range" min="0" max="5" step="1" value="${value||0}" onchange="updateQualityField('${section}','${key}',this.value)"></label>`;
}
function qNumber(section,key,label,value){
  return `<label>${label}<input class="input" type="number" value="${value||0}" onchange="updateQualityField('${section}','${key}',this.value)"></label>`;
}
function cardQuality(item){
  item=ensureQualityEngine(item);
  let s=calcQualityScore(item);
  let q=item.qualityEngine;
  let m=item.moat||{};
  let f=item.financials||{};
  return `<section class="hero card"><div><span class="pill">Quality Engine</span><h2>Quality Score: ${s.qualityScore}/100</h2><p>${qStars(s.qualityScore)} · Moat ${s.moatScore} · Financial ${s.financialScore} · Business ${s.businessScore} · Management ${s.managementScore} · Growth ${s.growthScore}</p></div><div><strong style="font-size:42px">${s.qualityScore}</strong><br><span class="muted">Quality Score</span></div></section>
  <section class="metrics"><div class="metric"><span>Moat</span><strong>${s.moatScore}</strong></div><div class="metric"><span>Financial</span><strong>${s.financialScore}</strong></div><div class="metric"><span>Business</span><strong>${s.businessScore}</strong></div><div class="metric"><span>Growth</span><strong>${s.growthScore}</strong></div></section>
  <section class="grid">
    <div class="card"><h3>Economic Moat</h3>
      ${qSlider("moat","brand","Brand",m.brand)}
      ${qSlider("moat","switchingCosts","Switching Costs",m.switchingCosts)}
      ${qSlider("moat","networkEffect","Network Effect",m.networkEffect)}
      ${qSlider("moat","costAdvantage","Cost Advantage",m.costAdvantage)}
      ${qSlider("moat","scale","Scale",m.scale)}
      ${qSlider("moat","patents","Patents",m.patents)}
      ${qSlider("moat","regulatory","Regulatory",m.regulatory)}
    </div>
    <div class="card"><h3>Financial Strength</h3>
      ${qNumber("financials","revenueGrowth","Revenue Growth score / value",f.revenueGrowth)}
      ${qNumber("financials","epsGrowth","EPS Growth score / value",f.epsGrowth)}
      ${qNumber("financials","fcf","FCF score / value",f.fcf)}
      ${qNumber("financials","roe","ROE",f.roe)}
      ${qNumber("financials","roic","ROIC",f.roic)}
      ${qNumber("financials","grossMargin","Gross Margin",f.grossMargin)}
      ${qNumber("financials","operatingMargin","Operating Margin",f.operatingMargin)}
      ${qNumber("financials","netMargin","Net Margin",f.netMargin)}
      ${qNumber("financials","debtEquity","Debt / Equity",f.debtEquity)}
      ${qNumber("financials","interestCoverage","Interest Coverage",f.interestCoverage)}
    </div>
  </section>
  <section class="grid">
    <div class="card"><h3>Business Quality</h3>
      ${qSlider("business","understandableBusiness","Understandable Business",q.business.understandableBusiness)}
      ${qSlider("business","durableDemand","Durable Demand",q.business.durableDemand)}
      ${qSlider("business","pricingPower","Pricing Power",q.business.pricingPower)}
      ${qSlider("business","businessModel","Business Model",q.business.businessModel)}
      ${qSlider("business","cyclicality","Low Cyclicality",q.business.cyclicality)}
      <textarea class="input" rows="3" onchange="updateQualityNote('business',this.value)">${q.business.notes||""}</textarea>
    </div>
    <div class="card"><h3>Management</h3>
      ${qSlider("management","capitalAllocation","Capital Allocation",q.management.capitalAllocation)}
      ${qSlider("management","buybacks","Buybacks",q.management.buybacks)}
      ${qSlider("management","dividendPolicy","Dividend Policy",q.management.dividendPolicy)}
      ${qSlider("management","insiderOwnership","Insider Ownership",q.management.insiderOwnership)}
      ${qSlider("management","communication","Communication",q.management.communication)}
      <textarea class="input" rows="3" onchange="updateQualityNote('management',this.value)">${q.management.notes||""}</textarea>
    </div>
  </section>
  <section class="card"><h3>Growth Potential</h3>
    ${qSlider("growth","tam","TAM",q.growth.tam)}
    ${qSlider("growth","innovation","Innovation",q.growth.innovation)}
    ${qSlider("growth","expansion","Expansion",q.growth.expansion)}
    ${qSlider("growth","newProducts","New Products",q.growth.newProducts)}
    ${qSlider("growth","international","International",q.growth.international)}
    <textarea class="input" rows="3" onchange="updateQualityNote('growth',this.value)">${q.growth.notes||""}</textarea>
  </section>`;
}


function ensureDecisionEngine(item){
  item=item||{};
  item.decisionEngine=item.decisionEngine||{};
  item.decisionEngine.priority=item.decisionEngine.priority||"B";
  item.decisionEngine.portfolioFit=Number(item.decisionEngine.portfolioFit ?? item.scores?.portfolioFit ?? 50);
  item.decisionEngine.opportunityScore=Number(item.decisionEngine.opportunityScore ?? item.scores?.opportunity ?? 50);
  item.decisionEngine.decisionScore=Number(item.decisionEngine.decisionScore ?? 50);
  item.decisionEngine.action=item.decisionEngine.action||item.action||"WATCH";
  item.decisionEngine.reason=item.decisionEngine.reason||"";
  item.decisionEngine.manualOverride=!!item.decisionEngine.manualOverride;
  return item.decisionEngine;
}
function calcDecisionScore(item){
  let d=ensureDecisionEngine(item);
  let quality=0;
  try{quality=calcQualityScore(item).qualityScore||0}catch(e){quality=Number(item.scores?.quality||0)}
  let fit=Number(d.portfolioFit||0);
  let opp=Number(d.opportunityScore||0);
  let priorityBoost=d.priority==="A"?10:d.priority==="B"?3:0;
  let score=Math.round(quality*0.4+fit*0.3+opp*0.3+priorityBoost);
  score=Math.max(0,Math.min(100,score));
  d.decisionScore=score;
  item.scores=item.scores||{};
  item.scores.portfolioFit=fit;
  item.scores.opportunity=opp;
  item.scores.mit=score;
  return score;
}
function autoDecisionAction(item){
  let d=ensureDecisionEngine(item);
  let score=calcDecisionScore(item);
  let owned=!!item.portfolio?.owned || item.status==="Owned";
  let weight=Number(item.portfolio?.positionWeight||0);
  let max=Number(item.portfolio?.maxWeight||item.portfolio?.targetMax||item.portfolio?.targetWeight||100);
  if(weight>max && owned) return "REDUCE";
  if(score>=80 && !owned) return "OPEN";
  if(score>=75 && owned) return "ADD";
  if(score>=60) return "HOLD";
  if(score>=45) return "WATCH";
  return "WAIT";
}
function decisionReason(item){
  let d=ensureDecisionEngine(item);
  let q=0;
  try{q=calcQualityScore(item).qualityScore||0}catch(e){q=Number(item.scores?.quality||0)}
  let act=d.action||autoDecisionAction(item);
  if(d.reason) return d.reason;
  if(act==="OPEN") return "Aukštas bendras balas ir pozicijos dar nėra.";
  if(act==="ADD") return "Pozicija turima, kokybė ir galimybė pakankamai geri papildymui.";
  if(act==="HOLD") return "Pozicija tinkama laikymui, bet ne stipriausias pirkimo signalas.";
  if(act==="WATCH") return "Reikia stebėti arba papildyti analizę.";
  if(act==="WAIT") return "Balai per silpni arba trūksta patrauklios progos.";
  if(act==="REDUCE") return "Pozicija gali viršyti ribas arba reikia mažinti riziką.";
  return "Sprendimas pagal Quality, Portfolio Fit ir Opportunity.";
}
function updateDecisionField(key,value){
  let item=findUniverseItem(activeCardType,activeCardId);
  if(!item)return;
  let d=ensureDecisionEngine(item);
  d[key]=value;
  if(key==="portfolioFit" || key==="opportunityScore") d[key]=Number(value);
  calcDecisionScore(item);
  if(!d.manualOverride) d.action=autoDecisionAction(item);
  item.action=d.action;
  if(typeof addTimeline==="function") addTimeline(item,"Decision updated",key);
  save();
}
function recalcDecision(){
  let item=findUniverseItem(activeCardType,activeCardId);
  if(!item)return;
  let d=ensureDecisionEngine(item);
  calcDecisionScore(item);
  if(!d.manualOverride) d.action=autoDecisionAction(item);
  item.action=d.action;
  if(typeof addTimeline==="function") addTimeline(item,"Decision recalculated",d.action);
  save();
}
function decisionBadge(action){
  let cls=(action==="OPEN"||action==="ADD")?"ok":(action==="HOLD"||action==="WATCH")?"warn":(action==="WAIT"||action==="REDUCE")?"bad":"info";
  return `<span class="badge ${cls}">${action}</span>`;
}
function cardDecision(item){
  let d=ensureDecisionEngine(item);
  let score=calcDecisionScore(item);
  if(!d.manualOverride) d.action=autoDecisionAction(item);
  item.action=d.action;
  let q=0;
  try{q=calcQualityScore(item).qualityScore||0}catch(e){q=Number(item.scores?.quality||0)}
  return `<section class="hero card"><div><span class="pill">Decision Engine</span><h2>${decisionBadge(d.action)} Decision Score: ${score}/100</h2><p>${decisionReason(item)}</p></div><div><strong style="font-size:42px">${score}</strong><br><span class="muted">Decision Score</span></div></section>
  <section class="metrics"><div class="metric"><span>Quality</span><strong>${q}</strong></div><div class="metric"><span>Portfolio Fit</span><strong>${d.portfolioFit}</strong></div><div class="metric"><span>Opportunity</span><strong>${d.opportunityScore}</strong></div><div class="metric"><span>Priority</span><strong>${d.priority}</strong></div></section>
  <section class="grid">
    <div class="card"><h3>Decision Inputs</h3>
      <label>Priority<select class="input" onchange="updateDecisionField('priority',this.value)"><option ${d.priority==="A"?"selected":""}>A</option><option ${d.priority==="B"?"selected":""}>B</option><option ${d.priority==="C"?"selected":""}>C</option></select></label>
      <label>Portfolio Fit: <strong>${d.portfolioFit}/100</strong><input class="input" type="range" min="0" max="100" step="1" value="${d.portfolioFit}" onchange="updateDecisionField('portfolioFit',this.value)"></label>
      <label>Opportunity Score: <strong>${d.opportunityScore}/100</strong><input class="input" type="range" min="0" max="100" step="1" value="${d.opportunityScore}" onchange="updateDecisionField('opportunityScore',this.value)"></label>
      <label><input type="checkbox" ${d.manualOverride?"checked":""} onchange="updateDecisionField('manualOverride',this.checked)"> Manual Override</label>
      <label>Action<select class="input" onchange="updateDecisionField('action',this.value)"><option ${d.action==="OPEN"?"selected":""}>OPEN</option><option ${d.action==="ADD"?"selected":""}>ADD</option><option ${d.action==="HOLD"?"selected":""}>HOLD</option><option ${d.action==="WATCH"?"selected":""}>WATCH</option><option ${d.action==="WAIT"?"selected":""}>WAIT</option><option ${d.action==="REDUCE"?"selected":""}>REDUCE</option></select></label>
      <button class="btn green" onclick="recalcDecision()">Recalculate Decision</button>
    </div>
    <div class="card"><h3>Reason</h3>
      <textarea class="input" rows="6" onchange="updateDecisionField('reason',this.value)">${d.reason||decisionReason(item)}</textarea>
      <div class="alert ok"><strong>Auto logic:</strong><br>Quality 40% + Portfolio Fit 30% + Opportunity 30% + Priority boost.</div>
    </div>
  </section>`;
}


function ensureMitScoreEngine(item){
  item=item||{};
  item.mitScoreEngine=item.mitScoreEngine||{};
  item.mitScoreEngine.weights=item.mitScoreEngine.weights||{quality:35,decision:25,research:15,confidence:10,portfolioFit:10,opportunity:5};
  item.mitScoreEngine.components=item.mitScoreEngine.components||{quality:0,decision:0,research:0,confidence:0,portfolioFit:0,opportunity:0};
  item.mitScoreEngine.score=Number(item.mitScoreEngine.score||0);
  item.mitScoreEngine.grade=item.mitScoreEngine.grade||"F";
  item.mitScoreEngine.comment=item.mitScoreEngine.comment||"";
  return item.mitScoreEngine;
}
function mitGrade(score){
  score=Number(score||0);
  if(score>=95)return "A+";
  if(score>=90)return "A";
  if(score>=80)return "B";
  if(score>=70)return "C";
  if(score>=60)return "D";
  return "F";
}
function mitGradeComment(score){
  score=Number(score||0);
  if(score>=95)return "Excellent candidate: labai stiprus bendras MIT balas.";
  if(score>=90)return "Strong candidate: labai gera investicija pagal MIT kriterijus.";
  if(score>=80)return "Good candidate: verta rimtai svarstyti pagal Decision.";
  if(score>=70)return "Average candidate: reikia daugiau analizės arba geresnės progos.";
  if(score>=60)return "Weak candidate: atsargiai, yra trūkumų.";
  return "Low score: vengti arba palikti tyrimui.";
}
function calcMitScore(item){
  let m=ensureMitScoreEngine(item);
  let quality=0, decision=0, research=0, confidence=0, portfolioFit=0, opportunity=0;
  try{quality=calcQualityScore(item).qualityScore||0}catch(e){quality=Number(item.scores?.quality||0)}
  try{decision=calcDecisionScore(item)||0}catch(e){decision=Number(item.decisionEngine?.decisionScore||item.scores?.mit||0)}
  try{research=richResearchPercent(item)||0}catch(e){research=0}
  confidence=Number(item.confidence||item.conviction*10||0);
  portfolioFit=Number(item.decisionEngine?.portfolioFit ?? item.scores?.portfolioFit ?? 0);
  opportunity=Number(item.decisionEngine?.opportunityScore ?? item.scores?.opportunity ?? 0);
  m.components={quality,decision,research,confidence,portfolioFit,opportunity};
  let w=m.weights||{quality:35,decision:25,research:15,confidence:10,portfolioFit:10,opportunity:5};
  let tw=Number(w.quality||0)+Number(w.decision||0)+Number(w.research||0)+Number(w.confidence||0)+Number(w.portfolioFit||0)+Number(w.opportunity||0);
  let score=(quality*w.quality+decision*w.decision+research*w.research+confidence*w.confidence+portfolioFit*w.portfolioFit+opportunity*w.opportunity)/(tw||100);
  score=Math.round(Math.max(0,Math.min(100,score)));
  m.score=score;
  m.grade=mitGrade(score);
  m.comment=mitGradeComment(score);
  item.scores=item.scores||{};
  item.scores.mit=score;
  return m;
}
function updateMitWeight(key,value){
  let item=findUniverseItem(activeCardType,activeCardId);
  if(!item)return;
  let m=ensureMitScoreEngine(item);
  m.weights[key]=Number(value);
  calcMitScore(item);
  if(typeof addTimeline==="function") addTimeline(item,"MIT Score updated","weight "+key);
  save();
}
function recalcMitScore(){
  let item=findUniverseItem(activeCardType,activeCardId);
  if(!item)return;
  calcMitScore(item);
  if(typeof addTimeline==="function") addTimeline(item,"MIT Score recalculated","MIT Score");
  save();
}
function scoreBar(label,value,weight){
  value=Number(value||0);
  return `<div class="card"><div class="bar-label"><span><strong>${label}</strong> · weight ${weight}%</span><span>${value}/100</span></div><div style="height:10px;background:#e5e7eb;border-radius:999px;overflow:hidden"><div style="height:10px;width:${Math.max(0,Math.min(100,value))}%;background:#2563eb"></div></div></div>`;
}
function cardMitScore(item){
  let m=calcMitScore(item);
  let c=m.components||{};
  let w=m.weights||{};
  return `<section class="hero card"><div><span class="pill">MIT Score Engine</span><h2>MIT Score: ${m.score}/100 · Grade ${m.grade}</h2><p>${m.comment}</p></div><div><strong style="font-size:42px">${m.grade}</strong><br><span class="muted">${m.score}/100</span></div></section>
  <section class="metrics"><div class="metric"><span>Quality</span><strong>${c.quality}</strong></div><div class="metric"><span>Decision</span><strong>${c.decision}</strong></div><div class="metric"><span>Research</span><strong>${c.research}%</strong></div><div class="metric"><span>Confidence</span><strong>${c.confidence}%</strong></div></section>
  <section class="grid">
    ${scoreBar("Quality Score",c.quality,w.quality)}
    ${scoreBar("Decision Score",c.decision,w.decision)}
    ${scoreBar("Research Progress",c.research,w.research)}
    ${scoreBar("Confidence",c.confidence,w.confidence)}
    ${scoreBar("Portfolio Fit",c.portfolioFit,w.portfolioFit)}
    ${scoreBar("Opportunity",c.opportunity,w.opportunity)}
  </section>
  <section class="grid">
    <div class="card"><h3>Weights</h3>
      <label>Quality %<input class="input" type="number" value="${w.quality}" onchange="updateMitWeight('quality',this.value)"></label>
      <label>Decision %<input class="input" type="number" value="${w.decision}" onchange="updateMitWeight('decision',this.value)"></label>
      <label>Research %<input class="input" type="number" value="${w.research}" onchange="updateMitWeight('research',this.value)"></label>
      <label>Confidence %<input class="input" type="number" value="${w.confidence}" onchange="updateMitWeight('confidence',this.value)"></label>
      <label>Portfolio Fit %<input class="input" type="number" value="${w.portfolioFit}" onchange="updateMitWeight('portfolioFit',this.value)"></label>
      <label>Opportunity %<input class="input" type="number" value="${w.opportunity}" onchange="updateMitWeight('opportunity',this.value)"></label>
      <button class="btn green" onclick="recalcMitScore()">Recalculate MIT Score</button>
    </div>
    <div class="card"><h3>Grade Scale</h3><table><tbody><tr><td>A+</td><td>95–100</td></tr><tr><td>A</td><td>90–94</td></tr><tr><td>B</td><td>80–89</td></tr><tr><td>C</td><td>70–79</td></tr><tr><td>D</td><td>60–69</td></tr><tr><td>F</td><td>&lt;60</td></tr></tbody></table><div class="alert ok"><strong>Pastaba:</strong> MIT Score nėra vien pirkimo signalas. Pirkimo veiksmą duoda Decision Engine.</div></div>
  </section>`;
}

function InvestmentCard(){
  let type=activeCardType||"stock";
  let id=activeCardId||(universe().stockUniverse[0]||{}).id;
  let item=findUniverseItem(type,id);
  if(!item)return `<section class="card"><h3>Investment Card</h3><div class="empty">Pasirink instrumentą iš Universe lentelių.</div></section>`;
  let content=activeCardTab==="overview"?cardOverview(item,type):activeCardTab==="research"?cardResearch(item):activeCardTab==="quality"?cardQuality(item):activeCardTab==="decision"?cardDecision(item):activeCardTab==="mitScore"?cardMitScore(item):activeCardTab==="financials"?cardFinancials(item):activeCardTab==="valuation"?cardValuation(item):activeCardTab==="thesis"?cardThesis(item):cardHistory(item);
  return `<section class="hero card"><div><span class="pill">Investment Card</span><h2>${item.ticker} — ${item.name||""}</h2><p>${item.status||""} · ${item.action||""} · ${item.analysisStatus||"New Idea"}</p></div><div><strong style="font-size:42px">${cardScore(item)}</strong><br><span class="muted">MIT Score</span></div></section>${cardQuickSummary(item)}<section class="card">${cardTabs()}</section>${content}`;
}

function Sync(){return `<section class="hero card"><div><span class="pill">Hard ID Fix</span><h2>Import Multiple DivvyDiary CSV</h2><p>Marius mygtukas rašo tik į PORT_MARIUS. Žmona mygtukas rašo tik į PORT_WIFE. Jokių pavadinimų spėjimų.</p></div></section><section class="grid"><div class="card"><h3>Marius Import</h3><label class="upload">Import Marius Files<input type="file" multiple accept=".csv" onchange="handleFiles(event,'PORT_MARIUS')"></label></div><div class="card"><h3>Žmona Import</h3><label class="upload">Import Žmona Files<input type="file" multiple accept=".csv" onchange="handleFiles(event,'PORT_WIFE')"></label></div></section><section class="card"><h3>Portfolio Assignment</h3>${portfolioAssignmentTable()}</section><section class="card"><h3>Sync Log</h3>${syncLog.map(x=>`<div class="alert ok">${x}</div>`).join("")||`<div class="empty">Sync log tuščias.</div>`}</section>`}
function External(){let types=["portfolio","assetAllocation","sectorAllocation","countryAllocation","regionAllocation","dividendHistory"];return `<section class="card"><h3>External Data by Portfolio</h3><table><thead><tr><th>Portfolio</th>${types.map(t=>`<th>${t}</th>`).join("")}</tr></thead><tbody>${["PORT_MARIUS","PORT_WIFE"].map(pid=>`<tr><td>${p(pid).name}</td>${types.map(t=>`<td>${(ext(pid)[t]||[]).length}</td>`).join("")}</tr>`).join("")}</tbody></table></section>`}

function Dividends(){
  let rows=dividendRowsEngineForView();
  let totalNet=rows.reduce((s,r)=>s+Number(r.totalNet||0),0);
  let totalGross=rows.reduce((s,r)=>s+Number(r.totalGross||0),0);
  let tax=totalGross-totalNet;
  return `<section class="metrics"><div class="metric"><span>Dividend rows</span><strong>${rows.length}</strong></div><div class="metric"><span>Total Gross</span><strong>${euro(totalGross)}</strong></div><div class="metric"><span>Total Net</span><strong>${euro(totalNet)}</strong></div><div class="metric"><span>Tax</span><strong>${euro(tax)}</strong></div></section>
  <section class="card"><h3>Dividend History — ${view==="family"?"Šeima":p(view).name}</h3>
  <div class="alert ok">Šis puslapis dabar naudoja tą pačią Dividend Engine istoriją kaip ir Dividend Engine modulis.</div>
  <table><thead><tr><th>Portfolio</th><th>Symbol</th><th>Ex</th><th>Pay</th><th>Qty</th><th>Gross</th><th>Net</th><th>Currency</th></tr></thead><tbody>${rows.slice().sort((a,b)=>String(b.payDate).localeCompare(String(a.payDate))).slice(0,300).map(r=>`<tr><td>${p(r.portfolioId).name||""}</td><td>${r.ticker||r.symbol||""}</td><td>${r.exDate}</td><td>${r.payDate}</td><td>${r.quantity}</td><td>${euro(r.totalGross)}</td><td>${euro(r.totalNet)}</td><td>${r.currency||""}</td></tr>`).join("")}</tbody></table></section>`;
}


function Summary(){return `<section class="card"><h3>Sync Summary</h3>${portfolioAssignmentTable()}</section>`}
function agg(list,fn,val=hv){let o={};list.forEach(h=>{let k=fn(h)||"Unknown";o[k]=(o[k]||0)+val(h)});return o}
function bars(obj,tot){let e=Object.entries(obj).sort((x,y)=>y[1]-x[1]);if(!e.length)return `<div class="empty">Nėra duomenų.</div>`;return e.map(([k,v],i)=>{let pp=tot?v/tot*100:0;return `<div class="bar"><div class="bar-label"><span>${k}</span><span>${pct(pp)} · ${euro(v)}</span></div><div class="bar-bg"><div class="bar-fill" style="width:${Math.min(pp,100)}%;background:${colors[i%colors.length]}"></div></div></div>`}).join("")}
function Portfolio(){
  let list=displayHoldings(), tv=total(list);
  let m=holdingsByPortfolio("PORT_MARIUS"), w=holdingsByPortfolio("PORT_WIFE");
  return `<section class="card"><h3>Portfolio — ${view==="family"?"Šeima":p(view).name}</h3>
  ${view==="family"?`<div class="alert ok">Šeimos suma: Marius ${euro(total(m))} + Žmona ${euro(total(w))} = ${euro(total(m)+total(w))}. Dubliai sujungti pagal ticker.</div>`:""}
  <table><thead><tr><th>Asset</th><th>Portfolio</th><th>Broker</th><th>Value</th><th>Weight</th><th>Sources</th></tr></thead><tbody>${list.map(h=>{
    let aa=a(h.assetId), ww=tv?hv(h)/tv*100:0;
    return `<tr><td><strong>${aa.ticker||"?"}</strong> — ${aa.name||""}</td><td>${portfolioLabelForHolding(h)}</td><td>${brokerLabelForHolding(h)}</td><td>${euro(h.currentValue)}</td><td>${pct(ww)}</td><td>${sourceLabelForHolding(h)}</td></tr>`;
  }).join("")}</tbody></table></section>`;
}
function Analytics(){let list=displayHoldings(),tv=total(list);return `<section class="grid"><div class="card"><h3>Asset Class</h3>${bars(agg(list,h=>a(h.assetId).type),tv)}</div><div class="card"><h3>Country</h3>${bars(agg(list,h=>a(h.assetId).country||a(h.assetId).region),tv)}</div><div class="card"><h3>Sector</h3>${bars(agg(list,h=>a(h.assetId).sector),tv)}</div><div class="card"><h3>Currency</h3>${bars(agg(list,h=>a(h.assetId).currency),tv)}</div></section>`}
function Validation(){return `<section class="card"><h3>Validation Prep</h3><div class="alert warn">Kitas žingsnis — MIT 1.3.2 Validation Center.</div></section>`}
function Settings(){return `<section class="grid"><div class="card"><h3>Sync Policies</h3><pre>${JSON.stringify(db.sync||{},null,2)}</pre></div><div class="card"><h3>Database</h3><pre>${JSON.stringify({version:db.version,stage:db.stage,assets:(db.assets||[]).length,holdings:(db.holdings||[]).length},null,2)}</pre></div></section>`}
function exportDb(){let blob=new Blob([JSON.stringify(db,null,2)],{type:"application/json"});let x=document.createElement("a");x.href=URL.createObjectURL(blob);x.download="MIT_2_0_2_database.json";x.click()}
function importDb(e){let f=e.target.files[0];if(!f)return;let r=new FileReader();r.onload=ev=>{try{db=JSON.parse(ev.target.result);localStorage.setItem("mit_2_0_2_fix2",JSON.stringify(db));render();alert("Importuota.")}catch(err){alert("Nepavyko importuoti JSON.")}};r.readAsText(f)}
function resetLocal(){if(confirm("Reset local MIT 2.0.2 FIX2 data?")){localStorage.removeItem("mit_2_0_2_fix2");db=MIT_DATABASE;syncLog=[];render()}}
render()
